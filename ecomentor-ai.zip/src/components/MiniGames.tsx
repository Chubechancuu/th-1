/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Gamepad2, Trophy, RefreshCcw, CheckCircle2, XCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const QUIZ_QUESTIONS = [
  {
    question: "What is the basic economic problem?",
    options: ["Scarcity", "Inflation", "Unemployment", "Overproduction"],
    correct: 0
  },
  {
    question: "Which of the following is a microeconomic topic?",
    options: ["GDP growth", "National debt", "Price of a single product", "Total employment"],
    correct: 2
  },
  {
    question: "What happens to demand when price increases (Law of Demand)?",
    options: ["Increases", "Decreases", "Stays the same", "Becomes zero"],
    correct: 1
  },
  {
    question: "Who is known as the 'Father of Economics'?",
    options: ["John Maynard Keynes", "Adam Smith", "Karl Marx", "Milton Friedman"],
    correct: 1
  }
];

export default function MiniGames() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);

  const handleAnswer = (index: number) => {
    if (selectedOption !== null) return;
    setSelectedOption(index);
    const correct = index === QUIZ_QUESTIONS[currentQuestion].correct;
    setIsCorrect(correct);
    if (correct) setScore(score + 1);

    setTimeout(() => {
      if (currentQuestion < QUIZ_QUESTIONS.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedOption(null);
        setIsCorrect(null);
      } else {
        setShowResult(true);
      }
    }, 1500);
  };

  const resetGame = () => {
    setCurrentQuestion(0);
    setScore(0);
    setShowResult(false);
    setSelectedOption(null);
    setIsCorrect(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold flex items-center gap-3">
          <Gamepad2 className="text-primary-brand" /> Economics Mini-Games
        </h2>
      </div>

      <div className="max-w-2xl mx-auto">
        <AnimatePresence mode="wait">
          {!showResult ? (
            <motion.div
              key="quiz"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="card p-8 space-y-8"
            >
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-text-muted uppercase tracking-widest">
                  Question {currentQuestion + 1} of {QUIZ_QUESTIONS.length}
                </span>
                <div className="flex items-center gap-2 text-primary-brand font-bold">
                  <Trophy size={16} /> {score}
                </div>
              </div>

              <div className="space-y-6">
                <h3 className="text-xl font-bold text-center leading-tight">
                  {QUIZ_QUESTIONS[currentQuestion].question}
                </h3>

                <div className="grid grid-cols-1 gap-3">
                  {QUIZ_QUESTIONS[currentQuestion].options.map((option, i) => {
                    let bgColor = 'bg-slate-50 border-border-main hover:border-primary-brand';
                    if (selectedOption === i) {
                      bgColor = isCorrect ? 'bg-emerald-50 border-secondary-brand ring-1 ring-secondary-brand' : 'bg-red-50 border-red-300 ring-1 ring-red-300';
                    } else if (selectedOption !== null && i === QUIZ_QUESTIONS[currentQuestion].correct) {
                      bgColor = 'bg-emerald-50 border-secondary-brand';
                    }

                    return (
                      <button
                        key={i}
                        onClick={() => handleAnswer(i)}
                        disabled={selectedOption !== null}
                        className={`w-full p-4 rounded-2xl border text-left transition-all flex items-center justify-between ${bgColor}`}
                      >
                        <span className="font-medium">{option}</span>
                        {selectedOption === i && (
                          isCorrect ? <CheckCircle2 className="text-secondary-brand" size={20} /> : <XCircle className="text-red-500" size={20} />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="result"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="card p-12 text-center space-y-6"
            >
              <div className="w-20 h-20 bg-amber-100 text-amber-500 rounded-full flex items-center justify-center mx-auto">
                <Trophy size={40} />
              </div>
              <div className="space-y-2">
                <h3 className="text-3xl font-black">Quiz Completed!</h3>
                <p className="text-text-muted">You scored {score} out of {QUIZ_QUESTIONS.length}</p>
              </div>
              <div className="pt-4">
                <button
                  onClick={resetGame}
                  className="btn btn-primary w-auto px-8 flex items-center gap-2 mx-auto"
                >
                  <RefreshCcw size={18} /> Play Again
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
