/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Check, Trash2, Clock, ChevronDown, ChevronUp, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Task } from '../types';

interface TaskItemProps {
  task: Task;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}

export const TaskItem: React.FC<TaskItemProps> = ({ task, onToggle, onDelete }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const priorityColors = {
    high: 'bg-red-100 text-red-600',
    medium: 'bg-amber-100 text-amber-600',
    low: 'bg-emerald-100 text-emerald-600',
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className={`group flex flex-col gap-2 p-4 rounded-2xl border transition-all bg-card-bg border-border-main ${
        task.completed ? 'opacity-50' : 'hover:shadow-md'
      }`}
    >
      <div className="flex items-center gap-4">
        <button
          onClick={() => onToggle(task.id)}
          className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all flex-shrink-0 ${
            task.completed 
              ? 'bg-primary-brand border-primary-brand' 
              : 'border-border-main hover:border-primary-brand'
          }`}
        >
          {task.completed && <Check size={14} className="text-white" />}
        </button>

        <div 
          className="flex-1 min-w-0 cursor-pointer"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          <h4 className={`font-bold text-[15px] truncate ${task.completed ? 'line-through text-text-muted' : 'text-text-main'}`}>
            {task.title}
          </h4>
          <div className="flex items-center gap-3 mt-0.5">
            <span className="text-[12px] text-text-muted font-medium flex items-center gap-1">
              {task.duration} mins
            </span>
            {task.notes && (
              <span className="text-[10px] text-primary-brand font-bold flex items-center gap-1">
                <FileText size={10} /> Has Notes
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-3">
          <span className={`px-2.5 py-1 rounded-md text-[11px] font-bold uppercase tracking-wider ${priorityColors[task.priority]}`}>
            {task.priority}
          </span>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 text-text-muted hover:text-primary-brand transition-all"
          >
            {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </button>
          <button
            onClick={() => onDelete(task.id)}
            className="opacity-0 group-hover:opacity-100 p-1.5 text-text-muted hover:text-red-500 transition-all"
            title="Delete Task"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isExpanded && task.notes && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="mt-2 pt-3 border-t border-border-main">
              <p className="text-sm text-text-muted whitespace-pre-wrap leading-relaxed">
                {task.notes}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};


export default TaskItem;
