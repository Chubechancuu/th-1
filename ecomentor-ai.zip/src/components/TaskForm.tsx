/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Plus, Clock } from 'lucide-react';
import { Priority } from '../types';

interface TaskFormProps {
  onAdd: (title: string, priority: Priority, duration: number, notes?: string) => void;
}

export default function TaskForm({ onAdd }: TaskFormProps) {
  const [title, setTitle] = useState('');
  const [priority, setPriority] = useState<Priority>('medium');
  const [duration, setDuration] = useState(25);
  const [notes, setNotes] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    onAdd(title, priority, duration, notes.trim() || undefined);
    setTitle('');
    setNotes('');
  };

  return (
    <form onSubmit={handleSubmit} className="card space-y-4">
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-sm font-bold text-text-muted uppercase tracking-wider">New Task</h2>
      </div>
      
      <div className="space-y-4">
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="What are you studying?"
          className="w-full bg-slate-50 border border-border-main rounded-xl px-4 py-3 outline-none focus:border-primary-brand transition-all text-sm"
        />

        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Add notes or details..."
          rows={3}
          className="w-full bg-slate-50 border border-border-main rounded-xl px-4 py-3 outline-none focus:border-primary-brand transition-all text-sm resize-none"
        />
        
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value as Priority)}
              className="w-full bg-slate-50 border border-border-main rounded-xl px-4 py-3 text-xs font-bold text-text-main outline-none appearance-none cursor-pointer"
            >
              <option value="high">🔴 High</option>
              <option value="medium">🟡 Medium</option>
              <option value="low">🟢 Low</option>
            </select>
          </div>
          
          <div className="w-24 relative">
            <input
              type="number"
              value={duration}
              onChange={(e) => setDuration(parseInt(e.target.value) || 0)}
              placeholder="Mins"
              className="w-full bg-slate-50 border border-border-main rounded-xl px-4 py-3 text-xs font-bold text-text-main outline-none text-center"
            />
          </div>
        </div>

        <button
          type="submit"
          className="btn btn-primary"
        >
          Add to Schedule
        </button>
      </div>
    </form>
  );

}
