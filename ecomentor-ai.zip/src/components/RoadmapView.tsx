/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Map, CheckCircle2, Circle, Clock, Sparkles, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Roadmap, RoadmapStep } from '../types';

interface RoadmapViewProps {
  roadmap: Roadmap | null;
  onGenerate: () => void;
  isGenerating: boolean;
  onToggleStep: (id: string) => void;
}

export default function RoadmapView({ roadmap, onGenerate, isGenerating, onToggleStep }: RoadmapViewProps) {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold flex items-center gap-3">
          <Map className="text-primary-brand" /> Your 4-Year Roadmap
        </h2>
        <button
          onClick={onGenerate}
          disabled={isGenerating}
          className="btn btn-primary w-auto px-6 flex items-center gap-2"
        >
          {isGenerating ? <Loader2 className="animate-spin" size={18} /> : <Sparkles size={18} />}
          {roadmap ? 'Regenerate Roadmap' : 'Generate Roadmap'}
        </button>
      </div>

      {!roadmap && !isGenerating && (
        <div className="text-center py-20 border-2 border-dashed border-border-main rounded-[24px]">
          <p className="text-text-muted">No roadmap generated yet. Click the button above to start your journey!</p>
        </div>
      )}

      {roadmap && (
        <div className="space-y-8">
          <div className="bg-gradient-to-br from-indigo-50 to-blue-50 border border-indigo-100 p-6 rounded-[24px]">
            <h4 className="font-bold text-sm text-primary-brand uppercase tracking-widest mb-2 flex items-center gap-2">
              <Sparkles size={14} /> Mentor's Advice
            </h4>
            <p className="text-sm text-indigo-900/80 leading-relaxed italic">
              "{roadmap.advice}"
            </p>
          </div>

          <div className="relative space-y-4">
            {/* Timeline line */}
            <div className="absolute left-[19px] top-4 bottom-4 w-0.5 bg-border-main" />

            <AnimatePresence mode="popLayout">
              {roadmap.steps.map((step, index) => (
                <motion.div
                  key={step.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="relative pl-12"
                >
                  <button
                    onClick={() => onToggleStep(step.id)}
                    className={`absolute left-0 top-1 w-10 h-10 rounded-full border-2 bg-white flex items-center justify-center transition-all z-10 ${
                      step.status === 'completed' 
                        ? 'border-secondary-brand text-secondary-brand' 
                        : 'border-border-main text-text-muted hover:border-primary-brand'
                    }`}
                  >
                    {step.status === 'completed' ? <CheckCircle2 size={20} /> : <Circle size={20} />}
                  </button>

                  <div className={`card ${step.status === 'completed' ? 'opacity-60' : ''}`}>
                    <div className="flex justify-between items-start mb-2">
                      <h3 className={`font-bold ${step.status === 'completed' ? 'line-through' : ''}`}>
                        {step.title}
                      </h3>
                      <span className="text-[10px] font-bold bg-slate-100 px-2 py-1 rounded-md text-text-muted uppercase flex items-center gap-1">
                        <Clock size={10} /> {step.timeframe}
                      </span>
                    </div>
                    <p className="text-sm text-text-muted leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      )}
    </div>
  );
}
