/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User, BookOpen, Target, FileText, Save } from 'lucide-react';
import { UserProfile } from '../types';

interface ProfileViewProps {
  profile: UserProfile;
  onSave: (profile: UserProfile) => void;
}

export default function ProfileView({ profile, onSave }: ProfileViewProps) {
  const [editedProfile, setEditedProfile] = useState<UserProfile>(profile);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(editedProfile);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold flex items-center gap-3">
          <User className="text-primary-brand" /> Your Profile (CV)
        </h2>
      </div>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card space-y-4">
          <h3 className="font-bold text-sm text-text-muted uppercase tracking-wider flex items-center gap-2">
            <User size={16} /> Basic Information
          </h3>
          
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-text-muted mb-1">Full Name</label>
              <input
                type="text"
                value={editedProfile.name}
                onChange={(e) => setEditedProfile({ ...editedProfile, name: e.target.value })}
                className="w-full bg-slate-50 border border-border-main rounded-xl px-4 py-2 text-sm outline-none focus:border-primary-brand"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-text-muted mb-1">Major</label>
              <input
                type="text"
                value={editedProfile.major}
                onChange={(e) => setEditedProfile({ ...editedProfile, major: e.target.value })}
                className="w-full bg-slate-50 border border-border-main rounded-xl px-4 py-2 text-sm outline-none focus:border-primary-brand"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-text-muted mb-1">Year of Study</label>
              <select
                value={editedProfile.year}
                onChange={(e) => setEditedProfile({ ...editedProfile, year: parseInt(e.target.value) })}
                className="w-full bg-slate-50 border border-border-main rounded-xl px-4 py-2 text-sm outline-none focus:border-primary-brand"
              >
                <option value={1}>Year 1</option>
                <option value={2}>Year 2</option>
                <option value={3}>Year 3</option>
                <option value={4}>Year 4</option>
              </select>
            </div>
          </div>
        </div>

        <div className="card space-y-4">
          <h3 className="font-bold text-sm text-text-muted uppercase tracking-wider flex items-center gap-2">
            <Target size={16} /> Goals & Skills
          </h3>
          
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-text-muted mb-1">Career Goals</label>
              <textarea
                value={editedProfile.goals}
                onChange={(e) => setEditedProfile({ ...editedProfile, goals: e.target.value })}
                rows={3}
                className="w-full bg-slate-50 border border-border-main rounded-xl px-4 py-2 text-sm outline-none focus:border-primary-brand resize-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-text-muted mb-1">Skills (comma separated)</label>
              <input
                type="text"
                value={editedProfile.skills.join(', ')}
                onChange={(e) => setEditedProfile({ ...editedProfile, skills: e.target.value.split(',').map(s => s.trim()) })}
                className="w-full bg-slate-50 border border-border-main rounded-xl px-4 py-2 text-sm outline-none focus:border-primary-brand"
              />
            </div>
          </div>
        </div>

        <div className="card md:col-span-2 space-y-4">
          <h3 className="font-bold text-sm text-text-muted uppercase tracking-wider flex items-center gap-2">
            <FileText size={16} /> CV Content / Experience
          </h3>
          <textarea
            value={editedProfile.cvContent}
            onChange={(e) => setEditedProfile({ ...editedProfile, cvContent: e.target.value })}
            rows={6}
            placeholder="Describe your background, projects, and experiences..."
            className="w-full bg-slate-50 border border-border-main rounded-xl px-4 py-3 text-sm outline-none focus:border-primary-brand resize-none"
          />
        </div>

        <div className="md:col-span-2 flex justify-end">
          <button type="submit" className="btn btn-primary w-auto px-8 flex items-center gap-2">
            <Save size={18} /> Save Profile
          </button>
        </div>
      </form>
    </div>
  );
}
