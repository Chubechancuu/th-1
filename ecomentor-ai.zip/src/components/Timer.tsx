/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Coffee } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface TimerProps {
  onComplete: () => void;
}

export default function Timer({ onComplete }: TimerProps) {
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [mode, setMode] = useState<'focus' | 'break'>('focus');
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isRunning && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsRunning(false);
      onComplete();
      if (mode === 'focus') {
        setMode('break');
        setTimeLeft(5 * 60);
      } else {
        setMode('focus');
        setTimeLeft(25 * 60);
      }
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning, timeLeft, mode, onComplete]);

  const toggleTimer = () => setIsRunning(!isRunning);

  const resetTimer = () => {
    setIsRunning(false);
    setTimeLeft(mode === 'focus' ? 25 * 60 : 5 * 60);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = (timeLeft / (mode === 'focus' ? 25 * 60 : 5 * 60)) * 100;

  return (
    <div className="card text-center relative overflow-hidden">
      <div className="relative z-10">
        <div className="flex items-center justify-center gap-2 mb-4">
          {mode === 'focus' ? (
            <span className="text-xs font-bold text-primary-brand uppercase tracking-widest">Focus Session</span>
          ) : (
            <span className="text-xs font-bold text-secondary-brand uppercase tracking-widest flex items-center gap-1">
              <Coffee size={14} /> Short Break
            </span>
          )}
        </div>

        <div className="relative w-[180px] h-[180px] mx-auto mb-6">
          <svg className="w-full h-full -rotate-90">
            <circle
              cx="90"
              cy="90"
              r="82"
              className="fill-none stroke-border-main stroke-[8]"
            />
            <motion.circle
              cx="90"
              cy="90"
              r="82"
              className={`fill-none stroke-[8] ${mode === 'focus' ? 'stroke-primary-brand' : 'stroke-secondary-brand'}`}
              strokeDasharray={515}
              initial={{ strokeDashoffset: 515 }}
              animate={{ strokeDashoffset: 515 - (515 * progress) / 100 }}
              transition={{ duration: 1, ease: 'linear' }}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <motion.div 
              key={timeLeft}
              initial={{ scale: 0.95, opacity: 0.8 }}
              animate={{ scale: 1, opacity: 1 }}
              className="text-4xl font-bold text-text-main font-mono tabular-nums"
            >
              {formatTime(timeLeft)}
            </motion.div>
          </div>
        </div>

        <div className="flex flex-col gap-2">
          <button
            onClick={toggleTimer}
            className="btn btn-primary"
          >
            {isRunning ? 'Pause Session' : 'Start Session'}
          </button>
          
          <button
            onClick={resetTimer}
            className="btn btn-outline text-xs"
          >
            Reset Timer
          </button>
        </div>
      </div>
    </div>
  );

}
