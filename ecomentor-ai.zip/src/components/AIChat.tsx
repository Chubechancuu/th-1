/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, Send, Bot, User, Loader2, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ChatMessage } from '../types';

interface AIChatProps {
  messages: ChatMessage[];
  onSendMessage: (content: string) => void;
  isSending: boolean;
}

export default function AIChat({ messages, onSendMessage, isSending }: AIChatProps) {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isSending]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isSending) return;
    onSendMessage(input.trim());
    setInput('');
  };

  return (
    <div className="flex flex-col h-[600px] card p-0 overflow-hidden">
      <div className="p-4 border-b border-border-main flex items-center justify-between bg-slate-50/50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary-brand rounded-xl flex items-center justify-center text-white">
            <Bot size={24} />
          </div>
          <div>
            <h3 className="font-bold text-sm">EcoMentor Companion</h3>
            <p className="text-[10px] text-secondary-brand font-bold uppercase tracking-widest flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-secondary-brand rounded-full animate-pulse" /> Online
            </p>
          </div>
        </div>
        <div className="text-text-muted">
          <Sparkles size={20} />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scroll">
        {messages.length === 0 && (
          <div className="text-center py-10">
            <p className="text-text-muted text-sm italic">"Hello! I'm your EcoMentor companion. How can I help you today?"</p>
          </div>
        )}
        
        {messages.map((msg, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div className={`flex gap-3 max-w-[80%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                msg.role === 'user' ? 'bg-slate-100 text-text-muted' : 'bg-primary-brand text-white'
              }`}>
                {msg.role === 'user' ? <User size={16} /> : <Bot size={16} />}
              </div>
              <div className={`p-3 rounded-2xl text-sm leading-relaxed ${
                msg.role === 'user' 
                  ? 'bg-primary-brand text-white rounded-tr-none' 
                  : 'bg-slate-100 text-text-main rounded-tl-none'
              }`}>
                {msg.content}
              </div>
            </div>
          </motion.div>
        ))}
        
        {isSending && (
          <div className="flex justify-start">
            <div className="flex gap-3 max-w-[80%]">
              <div className="w-8 h-8 rounded-lg bg-primary-brand text-white flex items-center justify-center">
                <Bot size={16} />
              </div>
              <div className="bg-slate-100 p-3 rounded-2xl rounded-tl-none">
                <Loader2 className="animate-spin text-primary-brand" size={16} />
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSend} className="p-4 border-t border-border-main bg-slate-50/50">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask me anything about your studies..."
            className="flex-1 bg-white border border-border-main rounded-xl px-4 py-2 text-sm outline-none focus:border-primary-brand"
          />
          <button
            type="submit"
            disabled={!input.trim() || isSending}
            className="p-2 bg-primary-brand text-white rounded-xl hover:opacity-90 disabled:opacity-50 transition-all"
          >
            <Send size={20} />
          </button>
        </div>
      </form>
    </div>
  );
}
