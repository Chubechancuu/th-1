/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Briefcase, Send, Sparkles, Loader2, Award, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { InternshipTask } from '../types';

interface InternshipSimProps {
  onEvaluate: (task: InternshipTask, submission: string) => Promise<{ feedback: string, score: number }>;
}

const SAMPLE_TASKS: InternshipTask[] = [
  {
    id: '1',
    title: 'Market Analysis Report',
    description: 'Analyze the impact of rising interest rates on consumer spending in the retail sector. Provide a 200-word summary.'
  },
  {
    id: '2',
    title: 'Financial Statement Review',
    description: 'Explain the difference between Cash Flow from Operations and Net Income. Why might they differ significantly?'
  },
  {
    id: '3',
    title: 'Investment Pitch',
    description: 'Write a short pitch for a sustainable energy startup. Focus on the economic viability and long-term growth potential.'
  }
];

export default function InternshipSim({ onEvaluate }: InternshipSimProps) {
  const [selectedTask, setSelectedTask] = useState<InternshipTask | null>(null);
  const [submission, setSubmission] = useState('');
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [result, setResult] = useState<{ feedback: string, score: number } | null>(null);

  const handleEvaluate = async () => {
    if (!selectedTask || !submission.trim()) return;
    setIsEvaluating(true);
    try {
      const evaluation = await onEvaluate(selectedTask, submission);
      setResult(evaluation);
    } catch (error) {
      console.error(error);
    } finally {
      setIsEvaluating(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold flex items-center gap-3">
          <Briefcase className="text-primary-brand" /> AI Internship Practice
        </h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-4">
          <h3 className="font-bold text-sm text-text-muted uppercase tracking-wider">Available Tasks</h3>
          {SAMPLE_TASKS.map(task => (
            <button
              key={task.id}
              onClick={() => {
                setSelectedTask(task);
                setResult(null);
                setSubmission('');
              }}
              className={`w-full text-left p-4 rounded-2xl border transition-all ${
                selectedTask?.id === task.id 
                  ? 'border-primary-brand bg-primary-brand/5 ring-1 ring-primary-brand' 
                  : 'border-border-main bg-white hover:border-primary-brand/50'
              }`}
            >
              <h4 className="font-bold text-sm mb-1">{task.title}</h4>
              <p className="text-xs text-text-muted line-clamp-2">{task.description}</p>
            </button>
          ))}
        </div>

        <div className="lg:col-span-2 space-y-6">
          <AnimatePresence mode="wait">
            {selectedTask ? (
              <motion.div
                key={selectedTask.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-6"
              >
                <div className="card bg-slate-50 border-slate-200">
                  <h3 className="font-bold mb-2 flex items-center gap-2">
                    <AlertCircle size={18} className="text-primary-brand" /> Task Instructions
                  </h3>
                  <p className="text-sm text-text-muted leading-relaxed">{selectedTask.description}</p>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-bold text-text-muted">Your Submission</label>
                  <textarea
                    value={submission}
                    onChange={(e) => setSubmission(e.target.value)}
                    rows={8}
                    placeholder="Type your response here..."
                    className="w-full bg-white border border-border-main rounded-2xl px-4 py-4 text-sm outline-none focus:border-primary-brand resize-none shadow-sm"
                  />
                </div>

                <button
                  onClick={handleEvaluate}
                  disabled={!submission.trim() || isEvaluating}
                  className="btn btn-primary w-full flex items-center justify-center gap-2"
                >
                  {isEvaluating ? <Loader2 className="animate-spin" size={20} /> : <Sparkles size={20} />}
                  Submit for AI Evaluation
                </button>

                {result && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="card border-secondary-brand bg-emerald-50/30"
                  >
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-bold text-secondary-brand flex items-center gap-2">
                        <Award size={20} /> Evaluation Result
                      </h3>
                      <div className="text-2xl font-black text-secondary-brand">
                        {result.score}<span className="text-sm font-bold opacity-60">/100</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm font-bold text-text-main">Supervisor Feedback:</p>
                      <p className="text-sm text-text-muted leading-relaxed italic">
                        "{result.feedback}"
                      </p>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            ) : (
              <div className="h-full flex items-center justify-center text-center py-20 border-2 border-dashed border-border-main rounded-[32px]">
                <div className="space-y-2">
                  <Briefcase size={40} className="mx-auto text-border-main" />
                  <p className="text-text-muted">Select a task from the left to start practicing.</p>
                </div>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
