/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Sparkles, Brain, Calendar, History, Loader2, Info, Settings, Key, X, 
  User, Map, Briefcase, MessageSquare, Gamepad2, LayoutDashboard,
  Trophy, Flame, CheckCircle2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Task, Priority, UserProfile, Roadmap, ChatMessage, InternshipTask } from './types';
import { optimizeSchedule, generateRoadmap, chatWithAI, getInternshipFeedback } from './services/gemini';
import Timer from './components/Timer';
import TaskForm from './components/TaskForm';
import TaskItem from './components/TaskItem';
import ProfileView from './components/ProfileView';
import RoadmapView from './components/RoadmapView';
import AIChat from './components/AIChat';
import InternshipSim from './components/InternshipSim';
import MiniGames from './components/MiniGames';

type Tab = 'dashboard' | 'roadmap' | 'internship' | 'chat' | 'games' | 'profile';

export default function App() {
  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem('eco-mentor-tasks');
    return saved ? JSON.parse(saved) : [];
  });
  const [profile, setProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('eco-mentor-profile');
    return saved ? JSON.parse(saved) : {
      name: 'New Student',
      major: 'Economics',
      year: 1,
      skills: [],
      goals: '',
      cvContent: ''
    };
  });
  const [roadmap, setRoadmap] = useState<Roadmap | null>(() => {
    const saved = localStorage.getItem('eco-mentor-roadmap');
    return saved ? JSON.parse(saved) : null;
  });
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('eco-mentor-chat');
    return saved ? JSON.parse(saved) : [];
  });
  const [streak, setStreak] = useState(() => {
    const saved = localStorage.getItem('eco-mentor-streak');
    return saved ? parseInt(saved) : 5; // Default streak
  });

  const [apiKey, setApiKey] = useState(() => localStorage.getItem('eco-mentor-api-key') || '');
  const [showSettings, setShowSettings] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [isGeneratingRoadmap, setIsGeneratingRoadmap] = useState(false);
  const [isSendingChat, setIsSendingChat] = useState(false);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [aiAdvice, setAiAdvice] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem('eco-mentor-tasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('eco-mentor-profile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('eco-mentor-roadmap', JSON.stringify(roadmap));
  }, [roadmap]);

  useEffect(() => {
    localStorage.setItem('eco-mentor-chat', JSON.stringify(chatMessages));
  }, [chatMessages]);

  useEffect(() => {
    localStorage.setItem('eco-mentor-api-key', apiKey);
  }, [apiKey]);

  const addTask = (title: string, priority: Priority, duration: number, notes?: string) => {
    const newTask: Task = {
      id: crypto.randomUUID(),
      title,
      priority,
      duration,
      completed: false,
      createdAt: Date.now(),
      notes,
    };
    setTasks([newTask, ...tasks]);
  };

  const handleGenerateRoadmap = async () => {
    setIsGeneratingRoadmap(true);
    try {
      const newRoadmap = await generateRoadmap(profile, apiKey || undefined);
      setRoadmap(newRoadmap);
    } catch (error) {
      console.error(error);
      alert("Failed to generate roadmap. Check your API key.");
    } finally {
      setIsGeneratingRoadmap(false);
    }
  };

  const handleSendMessage = async (content: string) => {
    const newMessages: ChatMessage[] = [...chatMessages, { role: 'user', content }];
    setChatMessages(newMessages);
    setIsSendingChat(true);
    try {
      const response = await chatWithAI(newMessages, profile, apiKey || undefined);
      setChatMessages([...newMessages, { role: 'model', content: response }]);
    } catch (error) {
      console.error(error);
    } finally {
      setIsSendingChat(true);
      setIsSendingChat(false);
    }
  };

  const handleEvaluateInternship = async (task: InternshipTask, submission: string) => {
    return await getInternshipFeedback(task, submission, apiKey || undefined);
  };

  const toggleRoadmapStep = (id: string) => {
    if (!roadmap) return;
    const updatedSteps = roadmap.steps.map(s => 
      s.id === id ? { ...s, status: s.status === 'completed' ? 'pending' : 'completed' } as const : s
    );
    setRoadmap({ ...roadmap, steps: updatedSteps });
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-6">
            <aside className="flex flex-col gap-6">
              <Timer onComplete={() => {
                const audio = new Audio('https://actions.google.com/sounds/v1/alarms/beep_short.ogg');
                audio.play();
              }} />
              <div className="card bg-primary-brand text-white border-none">
                <h3 className="font-bold text-sm uppercase tracking-widest opacity-80 mb-4">Daily Progress</h3>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Flame className="text-amber-400" />
                    <span className="text-2xl font-black">{streak} Day Streak</span>
                  </div>
                </div>
                <div className="w-full bg-white/20 h-2 rounded-full overflow-hidden">
                  <div className="bg-white h-full w-[75%]" />
                </div>
                <p className="text-[11px] mt-2 opacity-80">Keep it up! You're in the top 10% of learners this week.</p>
              </div>
              <TaskForm onAdd={addTask} />
            </aside>
            <main className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold flex items-center gap-2">
                  <Calendar className="text-primary-brand" /> Today's Focus
                </h2>
                <button 
                  onClick={async () => {
                    setIsOptimizing(true);
                    try {
                      const result = await optimizeSchedule(tasks.filter(t => !t.completed), apiKey || undefined);
                      setTasks([...result.sortedTasks, ...tasks.filter(t => t.completed)]);
                      setAiAdvice(result.advice);
                    } catch (e) {
                      alert("Optimization failed. Check API key.");
                    } finally {
                      setIsOptimizing(false);
                    }
                  }}
                  disabled={isOptimizing || tasks.filter(t => !t.completed).length < 2}
                  className="btn btn-secondary w-auto px-4 py-2 text-xs flex items-center gap-2"
                >
                  {isOptimizing ? <Loader2 className="animate-spin" size={14} /> : <Brain size={14} />}
                  Optimize Schedule
                </button>
              </div>

              {aiAdvice && (
                <motion.div 
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-primary-brand/5 border border-primary-brand/20 p-4 rounded-2xl flex gap-3 items-start"
                >
                  <Info className="text-primary-brand shrink-0 mt-0.5" size={18} />
                  <p className="text-sm text-text-main leading-relaxed">
                    <span className="font-bold text-primary-brand">AI Advice:</span> {aiAdvice}
                  </p>
                </motion.div>
              )}

              <div className="space-y-3">
                <AnimatePresence mode="popLayout">
                  {tasks.filter(t => !t.completed).map(task => (
                    <TaskItem 
                      key={task.id} 
                      task={task} 
                      onToggle={(id) => setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t))}
                      onDelete={(id) => setTasks(tasks.filter(t => t.id !== id))}
                    />
                  ))}
                </AnimatePresence>
                {tasks.filter(t => !t.completed).length === 0 && (
                  <div className="text-center py-12 border-2 border-dashed border-border-main rounded-[32px]">
                    <p className="text-text-muted text-sm">No active tasks. Time to plan your next move!</p>
                  </div>
                )}
              </div>
            </main>
          </div>
        );
      case 'roadmap':
        return (
          <RoadmapView 
            roadmap={roadmap} 
            onGenerate={handleGenerateRoadmap} 
            isGenerating={isGeneratingRoadmap}
            onToggleStep={toggleRoadmapStep}
          />
        );
      case 'internship':
        return <InternshipSim onEvaluate={handleEvaluateInternship} />;
      case 'chat':
        return <AIChat messages={chatMessages} onSendMessage={handleSendMessage} isSending={isSendingChat} />;
      case 'games':
        return <MiniGames />;
      case 'profile':
        return <ProfileView profile={profile} onSave={setProfile} />;
    }
  };

  return (
    <div className="min-h-screen bg-bg-main flex">
      {/* Sidebar Navigation */}
      <nav className="w-64 bg-white border-r border-border-main flex flex-col p-6 sticky top-0 h-screen">
        <div className="mb-10">
          <h1 className="text-2xl font-black text-primary-brand flex items-center gap-2">
            EcoMentor <span className="text-text-main">AI</span>
          </h1>
          <p className="text-[10px] font-bold text-text-muted uppercase tracking-widest mt-1">Economics Career Partner</p>
        </div>

        <div className="flex-1 space-y-2">
          {[
            { id: 'dashboard', icon: LayoutDashboard, label: 'Dashboard' },
            { id: 'roadmap', icon: Map, label: '4-Year Roadmap' },
            { id: 'internship', icon: Briefcase, label: 'AI Internship' },
            { id: 'chat', icon: MessageSquare, label: 'AI Companion' },
            { id: 'games', icon: Gamepad2, label: 'Mini-Games' },
            { id: 'profile', icon: User, label: 'My Profile (CV)' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as Tab)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all ${
                activeTab === item.id 
                  ? 'bg-primary-brand text-white shadow-lg shadow-primary-brand/20' 
                  : 'text-text-muted hover:bg-slate-50 hover:text-text-main'
              }`}
            >
              <item.icon size={18} />
              {item.label}
            </button>
          ))}
        </div>

        <div className="pt-6 border-t border-border-main space-y-4">
          <div className="flex items-center gap-3 px-4">
            <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-primary-brand font-black">
              {profile.name.charAt(0)}
            </div>
            <div className="min-w-0">
              <p className="text-sm font-bold truncate">{profile.name}</p>
              <p className="text-[10px] text-text-muted">Year {profile.year} Student</p>
            </div>
          </div>
          <button 
            onClick={() => setShowSettings(true)}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold text-text-muted hover:bg-slate-50 transition-all"
          >
            <Settings size={18} />
            Settings
          </button>
        </div>
      </nav>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col">
        <header className="h-20 border-b border-border-main bg-white/80 backdrop-blur-md flex items-center justify-between px-8 sticky top-0 z-30">
          <div className="flex items-center gap-4">
            <h2 className="text-lg font-bold capitalize">{activeTab.replace('-', ' ')}</h2>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 bg-amber-50 px-3 py-1.5 rounded-full border border-amber-100">
              <Flame size={16} className="text-amber-500" />
              <span className="text-sm font-bold text-amber-700">{streak}</span>
            </div>
            <div className="flex items-center gap-2 bg-emerald-50 px-3 py-1.5 rounded-full border border-emerald-100">
              <Trophy size={16} className="text-emerald-500" />
              <span className="text-sm font-bold text-emerald-700">1,240 XP</span>
            </div>
            <div className="text-sm font-bold text-text-muted">
              {new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
            </div>
          </div>
        </header>

        <main className="p-8 max-w-6xl mx-auto w-full">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Settings Modal */}
      <AnimatePresence>
        {showSettings && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowSettings(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-md bg-white rounded-[32px] p-8 shadow-2xl border border-border-main"
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold flex items-center gap-2">
                  <Settings size={24} className="text-primary-brand" /> Settings
                </h3>
                <button onClick={() => setShowSettings(false)} className="text-text-muted hover:text-text-main">
                  <X size={24} />
                </button>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-bold text-text-muted mb-2 flex items-center gap-2">
                    <Key size={16} /> Gemini API Key
                  </label>
                  <input
                    type="password"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    placeholder="Enter your API key..."
                    className="w-full bg-slate-50 border border-border-main rounded-xl px-4 py-3 outline-none focus:border-primary-brand transition-all text-sm"
                  />
                  <p className="mt-2 text-[11px] text-text-muted leading-relaxed">
                    Your API key is stored locally in your browser. It's used to power the AI features.
                  </p>
                </div>
                
                <button
                  onClick={() => setShowSettings(false)}
                  className="btn btn-primary"
                >
                  Save Settings
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

