/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI, Type } from "@google/genai";
import { Task, AIResponse, UserProfile, Roadmap, ChatMessage, InternshipTask } from "../types";

export async function optimizeSchedule(tasks: Task[], customApiKey?: string): Promise<AIResponse> {
  const apiKey = customApiKey || process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("GEMINI_API_KEY is not set");

  const ai = new GoogleGenAI({ apiKey });
  const prompt = `
    You are a productivity and time management expert. 
    I have a list of study tasks with their priorities, estimated durations, and optional notes.
    Please reorder them to create the most effective study schedule.
    Consider factors like:
    - High priority tasks should generally come first.
    - Mix difficult (high duration/priority) tasks with easier ones to avoid burnout.
    - Use the notes to understand the context of each task.
    - Provide 2-3 sentences of encouraging advice based on the specific tasks.

    Tasks: ${JSON.stringify(tasks.map(t => ({ 
      id: t.id, 
      title: t.title, 
      priority: t.priority, 
      duration: t.duration,
      notes: t.notes 
    })))}
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          sortedTaskIds: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "The IDs of the tasks in the recommended order."
          },
          advice: {
            type: Type.STRING,
            description: "Encouraging advice for the user."
          }
        },
        required: ["sortedTaskIds", "advice"]
      }
    }
  });

  const result = JSON.parse(response.text || "{}");
  const sortedTasks = result.sortedTaskIds
    .map((id: string) => tasks.find(t => t.id === id))
    .filter(Boolean) as Task[];
  const missedTasks = tasks.filter(t => !result.sortedTaskIds.includes(t.id));
  
  return {
    sortedTasks: [...sortedTasks, ...missedTasks],
    advice: result.advice
  };
}

export async function generateRoadmap(profile: UserProfile, customApiKey?: string): Promise<Roadmap> {
  const apiKey = customApiKey || process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("GEMINI_API_KEY is not set");

  const ai = new GoogleGenAI({ apiKey });
  const prompt = `
    You are an expert academic and career mentor for economics students.
    Based on the following student profile, generate a clear 4-year study and career roadmap.
    
    Profile:
    - Name: ${profile.name}
    - Major: ${profile.major}
    - Year: ${profile.year}
    - Skills: ${profile.skills.join(', ')}
    - Goals: ${profile.goals}
    - CV Info: ${profile.cvContent}

    Provide a JSON response with:
    1. steps: An array of RoadmapStep objects (id, title, description, timeframe).
    2. advice: A general piece of advice for their journey.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          steps: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                title: { type: Type.STRING },
                description: { type: Type.STRING },
                timeframe: { type: Type.STRING }
              },
              required: ["id", "title", "description", "timeframe"]
            }
          },
          advice: { type: Type.STRING }
        },
        required: ["steps", "advice"]
      }
    }
  });

  const result = JSON.parse(response.text || "{}");
  return {
    steps: result.steps.map((s: any) => ({ ...s, status: 'pending' })),
    advice: result.advice
  };
}

export async function chatWithAI(messages: ChatMessage[], profile: UserProfile, customApiKey?: string): Promise<string> {
  const apiKey = customApiKey || process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("GEMINI_API_KEY is not set");

  const ai = new GoogleGenAI({ apiKey });
  const systemInstruction = `
    You are "EcoMentor AI", a supportive and knowledgeable companion for economics students.
    You know the student's profile: ${JSON.stringify(profile)}.
    Your tone is friendly, professional, and encouraging. 
    Help them with academic questions, career advice, or just be a supportive friend.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: messages.map(m => ({ role: m.role, parts: [{ text: m.content }] })),
    config: {
      systemInstruction
    }
  });

  return response.text || "I'm sorry, I couldn't process that.";
}

export async function getInternshipFeedback(task: InternshipTask, submission: string, customApiKey?: string): Promise<{ feedback: string, score: number }> {
  const apiKey = customApiKey || process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("GEMINI_API_KEY is not set");

  const ai = new GoogleGenAI({ apiKey });
  const prompt = `
    You are a supervisor at a top economics firm. 
    Evaluate the following student submission for the task: "${task.title}".
    Task Description: ${task.description}
    Student Submission: ${submission}

    Provide constructive feedback and a score out of 100.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          feedback: { type: Type.STRING },
          score: { type: Type.NUMBER }
        },
        required: ["feedback", "score"]
      }
    }
  });

  return JSON.parse(response.text || "{}");
}
