/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Priority = 'high' | 'medium' | 'low';

export interface Task {
  id: string;
  title: string;
  priority: Priority;
  duration: number; // in minutes
  completed: boolean;
  createdAt: number;
  notes?: string;
}

export interface UserProfile {
  name: string;
  major: string;
  year: number;
  skills: string[];
  goals: string;
  cvContent: string;
}

export interface RoadmapStep {
  id: string;
  title: string;
  description: string;
  timeframe: string;
  status: 'pending' | 'in-progress' | 'completed';
}

export interface Roadmap {
  steps: RoadmapStep[];
  advice: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}

export interface InternshipTask {
  id: string;
  title: string;
  description: string;
  feedback?: string;
  score?: number;
}

export interface AIResponse {
  sortedTasks: Task[];
  advice: string;
}
