import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  BookOpen, 
  Briefcase, 
  MessageSquare, 
  UserCircle, 
  LogOut, 
  Menu, 
  X,
  Sparkles,
  CheckCircle2,
  Clock,
  Settings,
  Bell,
  Search,
  Moon,
  Sun
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Dashboard from './components/Dashboard';
import Learn from './components/Learn';
import Practice from './components/Practice';
import MentorChat from './components/MentorChat';
import Career from './components/Career';
import Pomodoro from './components/Pomodoro';
import TaskManager from './components/TaskManager';
import { UserProfile, Task, ChatMessage } from './types';
import { storage } from './lib/storage';
import { cn } from './lib/utils';

export default function App() {
  const [user, setUser] = useState<UserProfile>(storage.getUserProfile());
  const [tasks, setTasks] = useState<Task[]>(storage.getTasks());
  const [messages, setMessages] = useState<ChatMessage[]>(storage.getChatHistory());
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isDarkMode, setIsDarkMode] = useState(storage.getTheme() === 'dark');

  // Sync with storage
  useEffect(() => {
    storage.setUserProfile(user);
  }, [user]);

  useEffect(() => {
    storage.setTasks(tasks);
  }, [tasks]);

  useEffect(() => {
    storage.setChatHistory(messages);
  }, [messages]);

  useEffect(() => {
    storage.updateStreak();
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);

  const toggleDarkMode = () => {
    const newMode = !isDarkMode;
    setIsDarkMode(newMode);
    storage.setTheme(newMode ? 'dark' : 'light');
    document.documentElement.classList.toggle('dark');
  };

  const addXP = (amount: number) => {
    setUser(prev => {
      const newXP = prev.xp + amount;
      const newLevel = Math.floor(newXP / 1000) + 1;
      return { ...prev, xp: newXP, level: newLevel };
    });
  };

  const updateUser = (updates: Partial<UserProfile>) => {
    setUser(prev => ({ ...prev, ...updates } as UserProfile));
  };

  const handleOnboard = (data: Partial<UserProfile>) => {
    updateUser({ ...data, onboarded: true });
  };

  if (!user.onboarded) {
    return <Onboarding onComplete={handleOnboard} />;
  }

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'learn', label: 'Lộ trình học', icon: BookOpen },
    { id: 'practice', label: 'Thực tập ảo', icon: Briefcase },
    { id: 'mentor', label: 'AI Mentor', icon: MessageSquare },
    { id: 'career', label: 'CV Builder', icon: UserCircle },
  ];

  return (
    <div className="min-h-screen bg-bg flex overflow-hidden font-sans">
      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ width: isSidebarOpen ? 280 : 80 }}
        className="bg-surface border-r border-border flex flex-col z-40 relative"
      >
        <div className="p-6 flex items-center justify-between">
          <div className={cn("flex items-center gap-3 overflow-hidden", !isSidebarOpen && "hidden")}>
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white shadow-lg shadow-primary/20">
              <Sparkles size={24} />
            </div>
            <span className="font-black text-xl text-text-main tracking-tighter">AI CAREER</span>
          </div>
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 hover:bg-bg rounded-lg text-text-sub transition-colors"
          >
            {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        <nav className="flex-1 px-4 py-4 space-y-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "w-full flex items-center gap-4 px-4 py-3.5 rounded-xl transition-all group relative",
                activeTab === tab.id 
                  ? "bg-primary text-white shadow-lg shadow-primary/20" 
                  : "text-text-sub hover:bg-bg hover:text-text-main"
              )}
            >
              <tab.icon size={22} className={cn("shrink-0", activeTab === tab.id ? "text-white" : "group-hover:scale-110 transition-transform")} />
              {isSidebarOpen && <span className="font-bold text-[15px]">{tab.label}</span>}
              {activeTab === tab.id && (
                <motion.div layoutId="nav-pill" className="absolute left-0 w-1 h-6 bg-white rounded-r-full" />
              )}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-border space-y-2">
          <button 
            onClick={toggleDarkMode}
            className="w-full flex items-center gap-4 px-4 py-3 rounded-xl text-text-sub hover:bg-bg transition-all"
          >
            {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            {isSidebarOpen && <span className="font-bold text-[14px]">{isDarkMode ? 'Light Mode' : 'Dark Mode'}</span>}
          </button>
          <button className="w-full flex items-center gap-4 px-4 py-3 rounded-xl text-red-500 hover:bg-red-50 transition-all">
            <LogOut size={20} />
            {isSidebarOpen && <span className="font-bold text-[14px]">Đăng xuất</span>}
          </button>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden relative">
        {/* Top Header */}
        <header className="h-20 bg-surface/80 backdrop-blur-md border-b border-border px-8 flex items-center justify-between z-30">
          <div className="flex items-center gap-6 flex-1">
            <div className="relative max-w-md w-full hidden md:block">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-text-sub" size={18} />
              <input 
                type="text" 
                placeholder="Tìm kiếm tài liệu, lộ trình..."
                className="w-full bg-bg border border-border rounded-xl pl-12 pr-4 py-2.5 text-[14px] focus:outline-none focus:border-primary transition-all"
              />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button className="p-2.5 bg-bg rounded-xl text-text-sub hover:text-primary transition-all relative">
              <Bell size={20} />
              <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-surface" />
            </button>
            <div className="h-8 w-px bg-border mx-2" />
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <p className="text-[13px] font-black text-text-main leading-none">{user.name}</p>
                <p className="text-[11px] font-bold text-primary uppercase tracking-wider mt-1">Level {user.level}</p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary font-bold shadow-sm">
                {user.name.charAt(0)}
              </div>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
          <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-8">
            <div className="flex-1 min-w-0">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                >
                  {activeTab === 'dashboard' && <Dashboard user={user} updateUser={updateUser} />}
                  {activeTab === 'learn' && <Learn user={user} />}
                  {activeTab === 'practice' && <Practice user={user} addXP={addXP} />}
                  {activeTab === 'mentor' && <MentorChat user={user} messages={messages} setMessages={setMessages} />}
                  {activeTab === 'career' && <Career user={user} />}
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Right Sidebar - Widgets */}
            {activeTab === 'dashboard' && (
              <div className="w-full lg:w-80 space-y-8 shrink-0">
                <Pomodoro onComplete={(m) => addXP(m * 10)} />
                <TaskManager tasks={tasks} setTasks={setTasks} user={user} addXP={addXP} />
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

function Onboarding({ onComplete }: { onComplete: (data: Partial<UserProfile>) => void }) {
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({ name: '', goal: '', year: 'Năm 1', gpa: '' });

  const next = () => setStep(step + 1);

  return (
    <div className="min-h-screen bg-bg flex items-center justify-center p-6 font-sans">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-primary/5 rounded-full -translate-x-1/2 -translate-y-1/2 blur-3xl" />
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-secondary/5 rounded-full translate-x-1/2 translate-y-1/2 blur-3xl" />
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-surface p-10 rounded-[32px] border border-border shadow-2xl max-w-lg w-full relative z-10"
      >
        <div className="flex items-center gap-3 mb-10">
          <div className="w-12 h-12 bg-primary rounded-2xl flex items-center justify-center text-white shadow-lg shadow-primary/20">
            <Sparkles size={28} />
          </div>
          <div>
            <h2 className="text-2xl font-black text-text-main tracking-tight">AI Career Hub</h2>
            <p className="text-text-sub text-[13px] font-bold uppercase tracking-widest">Virtual Internship & Mentor</p>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div key="1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
              <h3 className="text-3xl font-black text-text-main leading-tight">Chào bạn! Tên bạn là gì nhỉ?</h3>
              <input 
                type="text" 
                value={form.name}
                onChange={(e) => setForm({...form, name: e.target.value})}
                placeholder="Nhập tên của bạn..."
                className="w-full bg-bg border-2 border-border rounded-[20px] px-6 py-4 text-lg focus:outline-none focus:border-primary transition-all font-bold"
              />
              <button 
                disabled={!form.name}
                onClick={next}
                className="w-full bg-primary text-white py-4 rounded-[20px] font-black text-lg shadow-lg shadow-primary/20 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50"
              >
                Tiếp tục
              </button>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div key="2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
              <h3 className="text-3xl font-black text-text-main leading-tight">Mục tiêu nghề nghiệp của bạn là gì?</h3>
              <div className="grid grid-cols-1 gap-3">
                {['Marketing Manager', 'Data Analyst', 'Financial Advisor', 'Logistics Specialist', 'HR Manager'].map((goal) => (
                  <button
                    key={goal}
                    onClick={() => setForm({...form, goal})}
                    className={cn(
                      "p-4 rounded-[18px] border-2 text-left font-bold transition-all",
                      form.goal === goal ? "bg-primary/10 border-primary text-primary" : "bg-bg border-border text-text-sub hover:border-primary/30"
                    )}
                  >
                    {goal}
                  </button>
                ))}
              </div>
              <input 
                type="text" 
                value={form.goal}
                onChange={(e) => setForm({...form, goal: e.target.value})}
                placeholder="Hoặc tự nhập mục tiêu khác..."
                className="w-full bg-bg border-2 border-border rounded-[20px] px-6 py-4 text-[15px] focus:outline-none focus:border-primary transition-all font-bold"
              />
              <button 
                disabled={!form.goal}
                onClick={next}
                className="w-full bg-primary text-white py-4 rounded-[20px] font-black text-lg shadow-lg shadow-primary/20 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50"
              >
                Tiếp tục
              </button>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div key="3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
              <h3 className="text-3xl font-black text-text-main leading-tight">Thông tin học tập hiện tại?</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-[12px] font-black text-text-sub uppercase tracking-widest mb-2">Năm học</label>
                  <select 
                    value={form.year}
                    onChange={(e) => setForm({...form, year: e.target.value})}
                    className="w-full bg-bg border-2 border-border rounded-[20px] px-6 py-4 font-bold focus:outline-none focus:border-primary appearance-none"
                  >
                    <option>Năm 1</option>
                    <option>Năm 2</option>
                    <option>Năm 3</option>
                    <option>Năm 4</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[12px] font-black text-text-sub uppercase tracking-widest mb-2">GPA hiện tại (VD: 3.5)</label>
                  <input 
                    type="text" 
                    value={form.gpa}
                    onChange={(e) => setForm({...form, gpa: e.target.value})}
                    placeholder="Nhập GPA của bạn..."
                    className="w-full bg-bg border-2 border-border rounded-[20px] px-6 py-4 font-bold focus:outline-none focus:border-primary transition-all"
                  />
                </div>
              </div>
              <button 
                onClick={() => onComplete(form)}
                className="w-full bg-primary text-white py-4 rounded-[20px] font-black text-lg shadow-lg shadow-primary/20 hover:scale-[1.02] active:scale-95 transition-all"
              >
                Bắt đầu hành trình
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="mt-10 flex justify-center gap-2">
          {[1, 2, 3].map((i) => (
            <div key={i} className={cn("h-1.5 rounded-full transition-all", step === i ? "w-8 bg-primary" : "w-2 bg-border")} />
          ))}
        </div>
      </motion.div>
    </div>
  );
}
