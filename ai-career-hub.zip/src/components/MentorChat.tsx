import React, { useState, useEffect, useRef } from 'react';
import { 
  Send, 
  Loader2, 
  User, 
  Bot, 
  Sparkles, 
  Trash2, 
  MessageSquare,
  ChevronRight,
  PlusCircle,
  BrainCircuit
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { UserProfile, ChatMessage } from '../types';
import { chatWithMentor } from '../lib/gemini';
import { cn } from '../lib/utils';
import ReactMarkdown from 'react-markdown';

interface MentorChatProps {
  user: UserProfile;
  messages: ChatMessage[];
  setMessages: (messages: ChatMessage[]) => void;
}

export default function MentorChat({ user, messages, setMessages }: MentorChatProps) {
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      role: 'user',
      content: input,
      timestamp: Date.now()
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput('');
    setIsLoading(true);

    try {
      const response = await chatWithMentor(newMessages, user);
      const mentorMessage: ChatMessage = {
        role: 'model',
        content: response,
        timestamp: Date.now()
      };
      setMessages([...newMessages, mentorMessage]);
    } catch (error) {
      console.error(error);
      const errorMessage: ChatMessage = {
        role: 'model',
        content: "Xin lỗi, tôi gặp chút trục trặc khi kết nối. Bạn có thể thử lại sau giây lát được không?",
        timestamp: Date.now()
      };
      setMessages([...newMessages, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const clearChat = () => {
    setMessages([]);
    setShowClearConfirm(false);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-180px)] max-w-5xl mx-auto w-full">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-primary/10 text-primary rounded-[16px] flex items-center justify-center shadow-sm">
            <BrainCircuit size={28} />
          </div>
          <div>
            <h1 className="text-2xl font-black text-text-main tracking-tight">AI Mentor Ngành Kinh Tế</h1>
            <p className="text-text-sub text-[13px] font-medium">Cố vấn lộ trình, CV và định hướng sự nghiệp 24/7</p>
          </div>
        </div>
        <div className="relative">
          <button 
            onClick={() => setShowClearConfirm(!showClearConfirm)}
            className="p-2.5 hover:bg-red-50 text-text-sub hover:text-red-500 rounded-xl transition-all border border-border hover:border-red-100"
            title="Xóa lịch sử"
          >
            <Trash2 size={20} />
          </button>
          
          <AnimatePresence>
            {showClearConfirm && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 10 }}
                className="absolute right-0 top-full mt-2 w-48 bg-surface border border-border rounded-xl p-3 shadow-xl z-50"
              >
                <p className="text-[12px] font-bold text-text-main mb-3">Xóa lịch sử trò chuyện?</p>
                <div className="flex gap-2">
                  <button 
                    onClick={() => setShowClearConfirm(false)}
                    className="flex-1 py-1.5 bg-bg text-text-sub text-[11px] font-bold rounded-lg hover:bg-border transition-colors"
                  >
                    Hủy
                  </button>
                  <button 
                    onClick={clearChat}
                    className="flex-1 py-1.5 bg-red-500 text-white text-[11px] font-bold rounded-lg hover:bg-red-600 transition-colors shadow-sm"
                  >
                    Xóa
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <div className="flex-1 bg-surface border border-border rounded-[24px] flex flex-col overflow-hidden shadow-sm relative">
        {/* Chat Messages */}
        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto p-6 space-y-8 custom-scrollbar scroll-smooth"
        >
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center max-w-md mx-auto space-y-6">
              <div className="w-20 h-20 bg-primary/5 rounded-full flex items-center justify-center text-primary animate-pulse">
                <Sparkles size={40} />
              </div>
              <div>
                <h3 className="text-xl font-black text-text-main mb-2">Chào {user.name}! Tôi là Mentor AI của bạn.</h3>
                <p className="text-text-sub text-[14px] leading-relaxed">
                  Tôi có thể giúp bạn tư vấn lộ trình 4 năm đại học, chọn chuyên ngành, sửa CV, luyện phỏng vấn hoặc gợi ý các chứng chỉ cần thiết.
                </p>
              </div>
              <div className="grid grid-cols-1 gap-2 w-full">
                {[
                  "Tư vấn lộ trình học Marketing năm 2",
                  "Nên học Excel hay Power BI trước?",
                  "Gợi ý các chứng chỉ cho ngành Tài chính",
                  "Sửa CV cho vị trí thực tập Logistics"
                ].map((suggestion, i) => (
                  <button 
                    key={i}
                    onClick={() => setInput(suggestion)}
                    className="text-left p-3 rounded-xl border border-border hover:border-primary/30 hover:bg-bg text-[13px] font-bold text-text-sub transition-all flex items-center justify-between group"
                  >
                    {suggestion}
                    <ChevronRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                  </button>
                ))}
              </div>
            </div>
          )}

          <AnimatePresence mode="popLayout">
            {messages.map((msg, idx) => (
              <motion.div
                key={msg.timestamp + idx}
                initial={{ opacity: 0, y: 10, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                className={cn(
                  "flex gap-4",
                  msg.role === 'user' ? "flex-row-reverse" : "flex-row"
                )}
              >
                <div className={cn(
                  "w-10 h-10 rounded-xl flex items-center justify-center shrink-0 shadow-sm",
                  msg.role === 'user' ? "bg-text-main text-white" : "bg-primary text-white"
                )}>
                  {msg.role === 'user' ? <User size={20} /> : <Bot size={20} />}
                </div>
                <div className={cn(
                  "max-w-[80%] p-5 rounded-[20px] shadow-sm",
                  msg.role === 'user' 
                    ? "bg-text-main text-white rounded-tr-none" 
                    : "bg-bg border border-border text-text-main rounded-tl-none"
                )}>
                  <div className="prose prose-sm max-w-none prose-headings:text-inherit prose-p:leading-relaxed prose-strong:text-primary">
                    <ReactMarkdown>{msg.content}</ReactMarkdown>
                  </div>
                  <div className={cn(
                    "text-[10px] mt-2 font-bold uppercase tracking-widest opacity-40",
                    msg.role === 'user' ? "text-right" : "text-left"
                  )}>
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          
          {isLoading && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex gap-4"
            >
              <div className="w-10 h-10 rounded-xl bg-primary text-white flex items-center justify-center shrink-0">
                <Bot size={20} />
              </div>
              <div className="bg-bg border border-border p-5 rounded-[20px] rounded-tl-none flex items-center gap-2">
                <Loader2 size={18} className="animate-spin text-primary" />
                <span className="text-[14px] font-bold text-text-sub">Mentor đang suy nghĩ...</span>
              </div>
            </motion.div>
          )}
        </div>

        {/* Input Area */}
        <div className="p-6 bg-surface border-t border-border">
          <div className="relative flex items-center gap-3">
            <div className="flex-1 relative">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                placeholder="Hỏi Mentor về lộ trình, CV, phỏng vấn..."
                className="w-full bg-bg border border-border rounded-[20px] px-6 py-4 pr-14 text-[15px] focus:outline-none focus:border-primary transition-all resize-none h-[56px] custom-scrollbar font-medium"
              />
              <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-2">
                <button className="p-1.5 text-text-sub hover:text-primary transition-colors">
                  <PlusCircle size={20} />
                </button>
              </div>
            </div>
            <button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className={cn(
                "w-[56px] h-[56px] rounded-[20px] flex items-center justify-center text-white transition-all shadow-lg",
                input.trim() && !isLoading 
                  ? "bg-primary shadow-primary/20 hover:scale-105 active:scale-95" 
                  : "bg-border cursor-not-allowed"
              )}
            >
              <Send size={24} />
            </button>
          </div>
          <p className="text-[11px] text-center text-text-sub mt-3 font-medium">
            Nhấn <b>Enter</b> để gửi, <b>Shift + Enter</b> để xuống dòng.
          </p>
        </div>
      </div>
    </div>
  );
}
