import React from 'react';
import { motion } from 'motion/react';
import { 
  Trophy, 
  Star, 
  Zap, 
  Award, 
  Target, 
  Flame,
  Lock,
  CheckCircle2
} from 'lucide-react';
import { UserProgress, Achievement } from '../types';
import { cn } from '../lib/utils';

interface AchievementsProps {
  progress: UserProgress;
}

const allAchievements: Achievement[] = [
  { id: '1', title: 'Người mới bắt đầu', description: 'Hoàn thành hồ sơ cá nhân lần đầu tiên.', icon: 'User' },
  { id: '2', title: 'Chiến binh lộ trình', description: 'Tạo lộ trình AI 4 năm đầu tiên.', icon: 'Map' },
  { id: '3', title: 'Thực tập sinh xuất sắc', description: 'Đạt điểm 100 trong một tình huống thực tập.', icon: 'Briefcase' },
  { id: '4', title: 'Siêu cấp tập trung', description: 'Hoàn thành 10 phiên Pomodoro.', icon: 'Timer' },
  { id: '5', title: 'Networking Master', description: 'Trò chuyện với Mentor AI 5 lần.', icon: 'MessageSquare' },
  { id: '6', title: 'Kiên trì bền bỉ', description: 'Đạt chuỗi học tập 7 ngày liên tiếp.', icon: 'Flame' },
];

export default function Achievements({ progress }: AchievementsProps) {
  const unlockedIds = progress.achievements.map(a => a.id);

  return (
    <div className="p-8 space-y-12">
      {/* Level Summary */}
      <div className="bg-text-main p-10 rounded-[2.5rem] text-white relative overflow-hidden shadow-lg">
        <div className="absolute top-0 right-0 p-12 opacity-5">
          <Trophy size={240} />
        </div>
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-12">
          <div className="relative">
            <div className="w-32 h-32 rounded-full border-4 border-white/10 flex items-center justify-center">
              <span className="text-5xl font-black">{progress.level}</span>
            </div>
            <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-primary px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-widest whitespace-nowrap">
              Cấp độ hiện tại
            </div>
          </div>
          <div className="flex-1 space-y-6 text-center md:text-left">
            <div>
              <h2 className="text-3xl font-black tracking-tight">Hành trình của bạn</h2>
              <p className="text-white/60 mt-2 text-sm">Bạn đã tích lũy được {progress.xp.toLocaleString()} XP. Cố gắng lên!</p>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest text-primary">
                <span>Tiến trình cấp độ</span>
                <span>{progress.xp % 1000} / 1000 XP</span>
              </div>
              <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${(progress.xp % 1000) / 10}%` }}
                  className="h-full bg-primary rounded-full"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Achievements Grid */}
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-bold text-text-main flex items-center gap-3">
            <Award className="text-primary" size={20} /> Danh hiệu đã đạt được
          </h3>
          <span className="text-[10px] font-bold text-text-sub uppercase tracking-widest">
            {unlockedIds.length} / {allAchievements.length} Đã mở khóa
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {allAchievements.map((achievement, idx) => {
            const isUnlocked = unlockedIds.includes(achievement.id);
            return (
              <motion.div
                key={achievement.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                className={cn(
                  "p-6 rounded-2xl border-2 transition-all relative group",
                  isUnlocked 
                    ? "bg-white border-primary-light shadow-sm" 
                    : "bg-slate-50 border-border grayscale opacity-60"
                )}
              >
                {!isUnlocked && (
                  <div className="absolute top-4 right-4 text-text-sub">
                    <Lock size={14} />
                  </div>
                )}
                {isUnlocked && (
                  <div className="absolute top-4 right-4 text-accent">
                    <CheckCircle2 size={14} />
                  </div>
                )}
                
                <div className={cn(
                  "w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-transform group-hover:scale-110",
                  isUnlocked ? "bg-primary-light text-primary" : "bg-slate-200 text-text-sub"
                )}>
                  <Star size={24} fill={isUnlocked ? "currentColor" : "none"} />
                </div>
                
                <h4 className="text-base font-bold text-text-main mb-1">{achievement.title}</h4>
                <p className="text-xs text-text-sub leading-relaxed">
                  {achievement.description}
                </p>

                {isUnlocked && (
                  <div className="mt-4 pt-4 border-t border-slate-50 flex items-center justify-between">
                    <span className="text-[9px] font-bold text-primary uppercase tracking-widest">Đã mở khóa</span>
                    <span className="text-[9px] text-text-sub font-bold">12/04/2024</span>
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Daily Streaks */}
      <div className="bg-slate-50 p-8 rounded-[2rem] border border-border flex flex-col md:flex-row items-center gap-8">
        <div className="w-20 h-20 rounded-2xl bg-white flex items-center justify-center shadow-sm border border-border">
          <Flame size={40} className="text-amber-500" fill="currentColor" />
        </div>
        <div className="flex-1 text-center md:text-left">
          <h3 className="text-xl font-bold text-text-main">Chuỗi học tập: {progress.streak} ngày</h3>
          <p className="text-text-sub mt-1 text-sm">Bạn đang làm rất tốt! Hãy duy trì thói quen học tập mỗi ngày nhé.</p>
        </div>
        <div className="flex gap-2">
          {[1, 2, 3, 4, 5, 6, 7].map((day) => (
            <div 
              key={day} 
              className={cn(
                "w-9 h-9 rounded-lg flex items-center justify-center font-bold text-[10px] transition-all",
                day <= progress.streak % 7 ? "bg-amber-500 text-white shadow-sm" : "bg-white text-text-sub border border-border"
              )}
            >
              T{day + 1}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
