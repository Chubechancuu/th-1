import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Map, 
  FileText, 
  Briefcase, 
  MessageSquare, 
  Settings, 
  Trophy,
  Timer,
  ChevronLeft,
  ChevronRight,
  LogOut,
  User
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const menuItems = [
  { id: 'dashboard', label: 'Tổng quan', icon: LayoutDashboard },
  { id: 'roadmap', label: 'Lộ trình AI', icon: Map },
  { id: 'cv', label: 'CV Builder', icon: FileText },
  { id: 'internship', label: 'Thực tập ảo', icon: Briefcase },
  { id: 'chat', label: 'Mentor AI', icon: MessageSquare },
  { id: 'achievements', label: 'Thành tích', icon: Trophy },
  { id: 'pomodoro', label: 'Tập trung', icon: Timer },
];

export default function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);

  return (
    <motion.aside
      initial={false}
      animate={{ width: isCollapsed ? 80 : 240 }}
      className="h-screen bg-white border-r border-border flex flex-col sticky top-0 z-50 transition-all duration-300 ease-in-out"
    >
      {/* Logo Section */}
      <div className="p-6 flex items-center justify-between">
        <AnimatePresence mode="wait">
          {!isCollapsed && (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex items-center gap-2"
            >
              <span className="font-extrabold text-xl text-primary">
                ◈ MentorNet AI
              </span>
            </motion.div>
          )}
        </AnimatePresence>
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="p-2 hover:bg-primary-light rounded-lg transition-colors text-text-sub"
        >
          {isCollapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-4 space-y-1">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={cn(
              "w-full flex items-center gap-3 px-6 py-3 transition-all duration-200 group relative text-sm font-medium",
              activeTab === item.id 
                ? "bg-primary-light text-primary border-r-4 border-primary" 
                : "text-text-sub hover:bg-slate-50 hover:text-text-main"
            )}
          >
            <item.icon size={18} className={cn(
              "transition-transform duration-200",
              activeTab === item.id ? "scale-110" : "group-hover:scale-110"
            )} />
            {!isCollapsed && (
              <span className="whitespace-nowrap">{item.label}</span>
            )}
          </button>
        ))}
      </nav>

      {/* User Profile Section */}
      <div className="p-4 border-t border-border">
        <div className={cn(
          "flex items-center gap-3 p-2 rounded-xl hover:bg-slate-50 transition-colors cursor-pointer",
          isCollapsed && "justify-center"
        )}>
          <div className="w-9 h-9 rounded-full bg-slate-200 flex items-center justify-center overflow-hidden border border-border shadow-sm">
            <User className="text-slate-400" size={18} />
          </div>
          {!isCollapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-text-main truncate">Minh Hoàng</p>
              <p className="text-[10px] text-text-sub truncate">Cấp độ 12 • 2,450 XP</p>
            </div>
          )}
        </div>
      </div>
    </motion.aside>
  );
}
