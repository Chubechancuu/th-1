import React from 'react';
import { UserProgress } from '../types';
import { motion } from 'motion/react';
import { 
  TrendingUp, 
  Award, 
  Clock, 
  Target,
  ArrowRight,
  Zap,
  Star,
  FileText,
  Briefcase
} from 'lucide-react';
import { cn } from '../lib/utils';

interface DashboardProps {
  progress: UserProgress;
}

export default function Dashboard({ progress }: DashboardProps) {
  const nextLevelXp = progress.level * 1000;
  const progressPercent = (progress.xp % 1000) / 10;

  const stats = [
    { label: 'Tổng XP', value: progress.xp.toLocaleString(), icon: Zap, color: 'text-amber-500', bg: 'bg-amber-50' },
    { label: 'Thành tích', value: progress.achievements.length, icon: Award, color: 'text-indigo-500', bg: 'bg-indigo-50' },
    { label: 'Chuỗi học', value: `${progress.streak} ngày`, icon: TrendingUp, color: 'text-emerald-500', bg: 'bg-emerald-50' },
    { label: 'Mục tiêu', value: '85%', icon: Target, color: 'text-rose-500', bg: 'bg-rose-50' },
  ];

  return (
    <div className="p-8 space-y-8">
      {/* Welcome Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Chào mừng trở lại! 👋</h2>
          <p className="text-slate-500 mt-1">Hôm nay bạn muốn phát triển kỹ năng nào?</p>
        </div>
        <div className="flex -space-x-2">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="w-10 h-10 rounded-full border-2 border-white bg-slate-200 overflow-hidden shadow-sm">
              <img src={`https://picsum.photos/seed/user${i}/100/100`} alt="User" referrerPolicy="no-referrer" />
            </div>
          ))}
          <div className="w-10 h-10 rounded-full border-2 border-white bg-indigo-600 flex items-center justify-center text-white text-xs font-bold shadow-sm">
            +12
          </div>
        </div>
      </div>

      {/* Level Progress */}
      <div className="sleek-card p-8 relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
          <Star size={120} className="text-primary rotate-12" />
        </div>
        <div className="relative z-10">
          <div className="flex items-end justify-between mb-4">
            <div>
              <span className="text-primary font-bold text-xs uppercase tracking-wider">Tiến trình cấp độ</span>
              <h3 className="text-2xl font-bold text-text-main mt-1">Cấp độ {progress.level}</h3>
            </div>
            <div className="text-right">
              <span className="text-text-sub text-xs">Tiếp theo: Cấp độ {progress.level + 1}</span>
              <p className="text-text-main font-bold">{progress.xp % 1000} / 1000 XP</p>
            </div>
          </div>
          <div className="h-3 bg-slate-100 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${progressPercent}%` }}
              className="h-full bg-primary rounded-full shadow-sm"
            />
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, idx) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="sleek-card p-6 hover:shadow-md transition-shadow"
          >
            <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center mb-4", stat.bg)}>
              <stat.icon className={stat.color} size={20} />
            </div>
            <p className="text-text-sub text-xs font-semibold uppercase tracking-wider">{stat.label}</p>
            <p className="text-2xl font-bold text-text-main mt-1">{stat.value}</p>
          </motion.div>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Tasks */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-text-main">Nhiệm vụ ưu tiên</h3>
            <button className="text-primary text-sm font-semibold hover:underline flex items-center gap-1">
              Xem tất cả <ArrowRight size={14} />
            </button>
          </div>
          <div className="space-y-4">
            {[
              { title: 'Hoàn thiện CV cá nhân', category: 'Sự nghiệp', time: '2 giờ trước', icon: FileText, color: 'bg-blue-50 text-blue-600' },
              { title: 'Thực tập tình huống: Xử lý hóa đơn', category: 'Thực tập', time: 'Hôm nay', icon: Briefcase, color: 'bg-purple-50 text-purple-600' },
              { title: 'Học Kinh tế vi mô: Chương 4', category: 'Học thuật', time: 'Ngày mai', icon: Map, color: 'bg-orange-50 text-orange-600' },
            ].map((task, idx) => (
              <div key={idx} className="sleek-card p-4 flex items-center gap-4 hover:border-primary transition-colors cursor-pointer group">
                <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center shrink-0", task.color)}>
                  <task.icon size={18} />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-text-main truncate group-hover:text-primary transition-colors">{task.title}</h4>
                  <div className="flex items-center gap-3 mt-0.5">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-text-sub">{task.category}</span>
                    <span className="w-1 h-1 bg-slate-300 rounded-full" />
                    <span className="text-[10px] text-text-sub">{task.time}</span>
                  </div>
                </div>
                <div className="w-5 h-5 rounded-full border border-border flex items-center justify-center group-hover:border-primary transition-colors">
                  <div className="w-2 h-2 rounded-full bg-transparent group-hover:bg-primary transition-colors" />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Coach Quick Tip */}
        <div className="space-y-6">
          <h3 className="text-xl font-bold text-text-main">Gợi ý từ Mentor AI</h3>
          <div className="bg-slate-900 p-6 rounded-2xl text-white shadow-lg relative overflow-hidden">
            <div className="absolute -bottom-4 -right-4 opacity-10">
              <Zap size={120} />
            </div>
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-7 h-7 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center">
                  <Star size={14} />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-widest opacity-60">Mẹo hôm nay</span>
              </div>
              <p className="text-base font-medium leading-relaxed italic">
                "Kỹ năng Networking không chỉ là gặp gỡ, mà là xây dựng giá trị. Hãy thử kết nối với 1 Mentor trong tuần này!"
              </p>
              <div className="mt-6 p-3 bg-white/5 rounded-lg border-l-2 border-amber-400 text-[11px] font-medium">
                <strong>Pro Tip:</strong> Khi đối thoại với nhà cung cấp, hãy luôn xác nhận bằng văn bản (email) ngay sau cuộc gọi.
              </div>
              <button className="mt-6 w-full py-2.5 bg-primary text-white rounded-xl font-bold hover:bg-blue-700 transition-colors shadow-sm text-sm">
                Bắt đầu ngay
              </button>
            </div>
          </div>

          {/* Activity Feed */}
          <div className="sleek-card p-6">
            <h4 className="font-bold text-text-main mb-4 text-sm uppercase tracking-wider">Hoạt động gần đây</h4>
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
                  <p className="text-xs text-text-sub leading-relaxed">
                    Bạn đã nhận được <span className="font-bold text-text-main">50 XP</span> từ việc hoàn thành bài học.
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
