import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  User, 
  Sparkles, 
  MessageSquare, 
  MoreVertical, 
  RefreshCw,
  Clock,
  Briefcase,
  BookOpen,
  TrendingUp
} from 'lucide-react';
import { ChatMessage } from '../types';
import { chatWithMentor } from '../services/gemini';
import { cn } from '../lib/utils';

export default function MentorChat() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'model',
      content: 'Chào bạn! Tôi là Mentor AI của bạn. Bạn cần tư vấn về lộ trình học tập, định hướng chuyên sâu hay kỹ năng nghề nghiệp nào không?',
      timestamp: new Date().toISOString()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      role: 'user',
      content: input,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const history = messages.map(m => ({ role: m.role, content: m.content }));
      const response = await chatWithMentor(input, history);
      
      const aiMessage: ChatMessage = {
        role: 'model',
        content: response,
        timestamp: new Date().toISOString()
      };
      
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error('Error chatting with mentor:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-8 h-[calc(100vh-64px)] flex gap-8">
      {/* Chat Area */}
      <div className="flex-1 flex flex-col bg-white rounded-3xl border border-border shadow-sm overflow-hidden">
        {/* Chat Header */}
        <div className="p-5 border-b border-border flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center shadow-sm">
              <Sparkles className="text-white" size={20} />
            </div>
            <div>
              <h3 className="font-bold text-text-main text-sm">Mentor AI</h3>
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
                <span className="text-[10px] font-bold text-text-sub uppercase tracking-wider">Đang trực tuyến</span>
              </div>
            </div>
          </div>
          <button className="p-2 hover:bg-slate-200 rounded-lg transition-colors text-text-sub">
            <MoreVertical size={18} />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {messages.map((msg, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn(
                "flex gap-3 max-w-[85%]",
                msg.role === 'user' ? "ml-auto flex-row-reverse" : ""
              )}
            >
              <div className={cn(
                "w-8 h-8 rounded-lg flex items-center justify-center shrink-0 shadow-sm",
                msg.role === 'user' ? "bg-primary" : "bg-slate-100"
              )}>
                {msg.role === 'user' ? <User size={16} className="text-white" /> : <Sparkles size={16} className="text-primary" />}
              </div>
              <div className={cn(
                "p-4 rounded-xl text-sm leading-relaxed",
                msg.role === 'user' 
                  ? "bg-primary text-white rounded-tr-none" 
                  : "bg-slate-100 text-text-main rounded-tl-none"
              )}>
                {msg.content}
                <p className={cn(
                  "text-[9px] mt-2 opacity-50 font-bold uppercase tracking-wider",
                  msg.role === 'user' ? "text-right" : "text-left"
                )}>
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </motion.div>
          ))}
          {isLoading && (
            <div className="flex gap-3 max-w-[85%]">
              <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center shrink-0">
                <Sparkles size={16} className="text-primary" />
              </div>
              <div className="bg-slate-100 p-4 rounded-xl rounded-tl-none flex gap-1 items-center">
                <div className="w-1 h-1 bg-text-sub rounded-full animate-bounce" />
                <div className="w-1 h-1 bg-text-sub rounded-full animate-bounce [animation-delay:0.2s]" />
                <div className="w-1 h-1 bg-text-sub rounded-full animate-bounce [animation-delay:0.4s]" />
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-5 border-t border-border bg-slate-50/50">
          <div className="flex gap-3">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Nhập câu hỏi của bạn tại đây..."
              className="flex-1 p-3.5 rounded-xl border border-border focus:ring-2 focus:ring-primary outline-none transition-all shadow-sm text-sm bg-white"
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className="w-12 h-12 bg-primary text-white rounded-xl flex items-center justify-center hover:bg-blue-700 disabled:opacity-50 transition-all shadow-sm"
            >
              <Send size={20} />
            </button>
          </div>
        </div>
      </div>

      {/* Sidebar Info */}
      <div className="w-72 space-y-6 hidden xl:block">
        <div className="sleek-card p-6 space-y-6">
          <h4 className="text-[10px] font-bold text-text-sub uppercase tracking-widest flex items-center gap-2">
            <Clock size={14} className="text-primary" /> Chủ đề gợi ý
          </h4>
          <div className="space-y-2">
            {[
              { label: 'Lộ trình học 4 năm', icon: BookOpen },
              { label: 'Kỹ năng phân tích', icon: TrendingUp },
              { label: 'Tìm kiếm thực tập', icon: Briefcase },
            ].map((topic, i) => (
              <button
                key={i}
                onClick={() => setInput(topic.label)}
                className="w-full p-3 rounded-xl border border-border hover:border-primary hover:bg-primary-light transition-all text-left flex items-center gap-3 group"
              >
                <div className="w-7 h-7 rounded-lg bg-slate-50 flex items-center justify-center group-hover:bg-white transition-colors">
                  <topic.icon size={14} className="text-text-sub group-hover:text-primary" />
                </div>
                <span className="text-xs font-bold text-text-sub group-hover:text-primary">{topic.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="bg-text-main p-6 rounded-3xl text-white shadow-lg relative overflow-hidden">
          <div className="absolute top-0 right-0 w-20 h-20 bg-primary/20 rounded-full -mr-10 -mt-10 blur-xl" />
          <div className="flex items-center gap-2 mb-4 relative z-10">
            <div className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center">
              <Sparkles size={14} className="text-primary" />
            </div>
            <span className="text-[9px] font-bold uppercase tracking-widest text-primary">AI Companion</span>
          </div>
          <p className="text-xs text-white/80 leading-relaxed relative z-10 italic">
            "Tôi có thể giúp bạn phân tích các lựa chọn môn học tự chọn để tối ưu hóa hồ sơ xin việc sau này."
          </p>
        </div>
      </div>
    </div>
  );
}
