import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Trash2, 
  Download, 
  Eye, 
  Edit3, 
  Mail, 
  Phone, 
  MapPin, 
  Globe,
  Briefcase,
  GraduationCap,
  Wrench,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { CVData, Experience, Education, Skill } from '../types';
import { cn } from '../lib/utils';

const initialCV: CVData = {
  personalInfo: {
    fullName: 'Nguyễn Văn A',
    email: 'nguyenvana@email.com',
    phone: '090 123 4567',
    address: 'Quận 1, TP. Hồ Chí Minh',
    summary: 'Sinh viên năm 2 ngành Kinh tế đối ngoại với niềm đam mê phân tích dữ liệu và tư vấn chiến lược. Luôn tìm kiếm cơ hội để áp dụng kiến thức học thuật vào thực tế.',
    role: 'Sinh viên Kinh tế / Thực tập sinh Phân tích'
  },
  experience: [
    {
      id: '1',
      company: 'CLB Kinh tế Trẻ',
      position: 'Trưởng ban Đối ngoại',
      startDate: '2023-09',
      endDate: 'Hiện tại',
      description: ['Quản lý quan hệ với 10+ đối tác doanh nghiệp', 'Tổ chức thành công 3 hội thảo quy mô 500+ sinh viên']
    }
  ],
  education: [
    {
      id: '1',
      school: 'Đại học Kinh tế TP.HCM (UEH)',
      degree: 'Cử nhân Kinh tế đối ngoại',
      startDate: '2022-09',
      endDate: '2026-06'
    }
  ],
  skills: [
    { name: 'Phân tích dữ liệu', level: 85 },
    { name: 'Tiếng Anh (IELTS)', level: 90 },
    { name: 'Microsoft Excel', level: 80 }
  ],
  languages: ['Tiếng Việt (Bản ngữ)', 'Tiếng Anh (C1)']
};

export default function CVBuilder() {
  const [cvData, setCvData] = useState<CVData>(initialCV);
  const [mode, setMode] = useState<'edit' | 'preview'>('edit');
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    contact: true,
    skills: true
  });

  const updatePersonalInfo = (field: string, value: string) => {
    setCvData(prev => ({
      ...prev,
      personalInfo: { ...prev.personalInfo, [field]: value }
    }));
  };

  const addExperience = () => {
    const newExp: Experience = {
      id: Date.now().toString(),
      company: '',
      position: '',
      startDate: '',
      endDate: '',
      description: ['']
    };
    setCvData(prev => ({ ...prev, experience: [...prev.experience, newExp] }));
  };

  const removeExperience = (id: string) => {
    setCvData(prev => ({ ...prev, experience: prev.experience.filter(e => e.id !== id) }));
  };

  const updateExperience = (id: string, field: string, value: any) => {
    setCvData(prev => ({
      ...prev,
      experience: prev.experience.map(e => e.id === id ? { ...e, [field]: value } : e)
    }));
  };

  return (
    <div className="p-8 max-w-6xl mx-auto">
      {/* Controls */}
      <div className="flex items-center justify-between mb-8 sleek-card p-3 sticky top-20 z-30">
        <div className="flex bg-slate-100 p-1 rounded-xl">
          <button
            onClick={() => setMode('edit')}
            className={cn(
              "px-6 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2",
              mode === 'edit' ? "bg-white text-primary shadow-sm" : "text-text-sub"
            )}
          >
            <Edit3 size={14} /> Chỉnh sửa
          </button>
          <button
            onClick={() => setMode('preview')}
            className={cn(
              "px-6 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2",
              mode === 'preview' ? "bg-white text-primary shadow-sm" : "text-text-sub"
            )}
          >
            <Eye size={14} /> Xem trước
          </button>
        </div>
        <button className="px-6 py-2 bg-primary text-white rounded-xl font-bold hover:bg-blue-700 transition-all flex items-center gap-2 shadow-sm text-xs">
          <Download size={14} /> Tải PDF
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Editor Side */}
        {mode === 'edit' && (
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            {/* Personal Info */}
            <section className="sleek-card p-6 space-y-4">
              <h3 className="text-sm font-bold text-text-main uppercase tracking-wider flex items-center gap-2">
                <Edit3 size={16} className="text-primary" /> Thông tin cá nhân
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-text-sub uppercase tracking-wider">Họ và tên</label>
                  <input 
                    value={cvData.personalInfo.fullName}
                    onChange={(e) => updatePersonalInfo('fullName', e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-border focus:ring-2 focus:ring-primary outline-none text-sm bg-slate-50"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-text-sub uppercase tracking-wider">Vị trí mong muốn</label>
                  <input 
                    value={cvData.personalInfo.role}
                    onChange={(e) => updatePersonalInfo('role', e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-border focus:ring-2 focus:ring-primary outline-none text-sm bg-slate-50"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-text-sub uppercase tracking-wider">Email</label>
                  <input 
                    value={cvData.personalInfo.email}
                    onChange={(e) => updatePersonalInfo('email', e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-border focus:ring-2 focus:ring-primary outline-none text-sm bg-slate-50"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-text-sub uppercase tracking-wider">Số điện thoại</label>
                  <input 
                    value={cvData.personalInfo.phone}
                    onChange={(e) => updatePersonalInfo('phone', e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-border focus:ring-2 focus:ring-primary outline-none text-sm bg-slate-50"
                  />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-text-sub uppercase tracking-wider">Địa chỉ</label>
                <input 
                  value={cvData.personalInfo.address}
                  onChange={(e) => updatePersonalInfo('address', e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-border focus:ring-2 focus:ring-primary outline-none text-sm bg-slate-50"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-text-sub uppercase tracking-wider">Tóm tắt bản thân</label>
                <textarea 
                  value={cvData.personalInfo.summary}
                  onChange={(e) => updatePersonalInfo('summary', e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-border focus:ring-2 focus:ring-primary outline-none min-h-[100px] text-sm bg-slate-50"
                />
              </div>
            </section>

            {/* Experience */}
            <section className="sleek-card p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-text-main uppercase tracking-wider flex items-center gap-2">
                  <Briefcase size={16} className="text-primary" /> Kinh nghiệm
                </h3>
                <button onClick={addExperience} className="p-1.5 bg-primary-light text-primary rounded-lg hover:bg-blue-100 transition-colors">
                  <Plus size={16} />
                </button>
              </div>
              {cvData.experience.map((exp) => (
                <div key={exp.id} className="p-4 border border-border rounded-xl space-y-4 relative group bg-slate-50/50">
                  <button 
                    onClick={() => removeExperience(exp.id)}
                    className="absolute top-4 right-4 text-text-sub hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-all"
                  >
                    <Trash2 size={14} />
                  </button>
                  <div className="grid grid-cols-2 gap-4">
                    <input 
                      placeholder="Công ty/Tổ chức"
                      value={exp.company}
                      onChange={(e) => updateExperience(exp.id, 'company', e.target.value)}
                      className="p-2.5 rounded-lg border border-border focus:ring-2 focus:ring-primary outline-none text-xs bg-white"
                    />
                    <input 
                      placeholder="Vị trí"
                      value={exp.position}
                      onChange={(e) => updateExperience(exp.id, 'position', e.target.value)}
                      className="p-2.5 rounded-lg border border-border focus:ring-2 focus:ring-primary outline-none text-xs bg-white"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <input 
                      placeholder="Bắt đầu (MM/YYYY)"
                      value={exp.startDate}
                      onChange={(e) => updateExperience(exp.id, 'startDate', e.target.value)}
                      className="p-2.5 rounded-lg border border-border focus:ring-2 focus:ring-primary outline-none text-xs bg-white"
                    />
                    <input 
                      placeholder="Kết thúc (MM/YYYY)"
                      value={exp.endDate}
                      onChange={(e) => updateExperience(exp.id, 'endDate', e.target.value)}
                      className="p-2.5 rounded-lg border border-border focus:ring-2 focus:ring-primary outline-none text-xs bg-white"
                    />
                  </div>
                </div>
              ))}
            </section>
          </motion.div>
        )}

        {/* Preview Side */}
        <div className={cn("lg:sticky lg:top-40", mode === 'edit' ? "hidden lg:block" : "block w-full max-w-2xl mx-auto")}>
          <div className="bg-white shadow-xl rounded-sm aspect-[1/1.41] overflow-hidden flex border border-border">
            {/* CV Sidebar */}
            <div className="w-1/3 bg-slate-100 text-text-main p-8 space-y-8 relative overflow-hidden border-r border-border">
              <div className="relative z-10 space-y-8">
                {/* Contact Section */}
                <div className="space-y-4">
                  <button 
                    onClick={() => setExpandedSections(s => ({ ...s, contact: !s.contact }))}
                    className="w-full flex items-center justify-between text-[10px] font-bold uppercase tracking-widest text-primary border-b border-border pb-2"
                  >
                    Liên hệ {expandedSections.contact ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                  </button>
                  <AnimatePresence>
                    {expandedSections.contact && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="space-y-3 overflow-hidden"
                      >
                        <div className="flex items-center gap-3 text-[9px]">
                          <Mail size={12} className="text-primary" />
                          <span className="truncate">{cvData.personalInfo.email || 'email@example.com'}</span>
                        </div>
                        <div className="flex items-center gap-3 text-[9px]">
                          <Phone size={12} className="text-primary" />
                          <span>{cvData.personalInfo.phone || '090 000 0000'}</span>
                        </div>
                        <div className="flex items-center gap-3 text-[9px]">
                          <MapPin size={12} className="text-primary" />
                          <span className="truncate">{cvData.personalInfo.address || 'Địa chỉ'}</span>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Skills Section */}
                <div className="space-y-4">
                  <button 
                    onClick={() => setExpandedSections(s => ({ ...s, skills: !s.skills }))}
                    className="w-full flex items-center justify-between text-[10px] font-bold uppercase tracking-widest text-primary border-b border-border pb-2"
                  >
                    Kỹ năng {expandedSections.skills ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                  </button>
                  <AnimatePresence>
                    {expandedSections.skills && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="space-y-4 overflow-hidden"
                      >
                        {cvData.skills.map((skill, i) => (
                          <div key={i} className="space-y-1.5">
                            <div className="flex justify-between text-[9px] font-bold">
                              <span>{skill.name}</span>
                              <span className="text-primary">{skill.level}%</span>
                            </div>
                            <div className="h-1 bg-slate-200 rounded-full overflow-hidden">
                              <motion.div 
                                initial={{ width: 0 }}
                                animate={{ width: `${skill.level}%` }}
                                className="h-full bg-primary"
                              />
                            </div>
                          </div>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </div>

            {/* CV Main Content */}
            <div className="flex-1 p-12 bg-white relative">
              <div className="relative z-10 space-y-10">
                {/* Header */}
                <div className="space-y-2">
                  <h1 className="text-3xl font-black text-text-main tracking-tight uppercase">
                    {cvData.personalInfo.fullName.split(' ').map((n, i) => (
                      <span key={i} className={i === cvData.personalInfo.fullName.split(' ').length - 1 ? "text-primary" : ""}>
                        {n}{' '}
                      </span>
                    ))}
                  </h1>
                  <p className="text-xs font-bold text-text-sub uppercase tracking-widest">
                    {cvData.personalInfo.role}
                  </p>
                </div>

                {/* Summary */}
                <div className="space-y-3">
                  <h2 className="text-[10px] font-black uppercase tracking-[0.2em] text-text-main border-b-2 border-primary pb-1 inline-block">
                    Tóm tắt
                  </h2>
                  <p className="text-[10px] text-text-sub leading-relaxed text-justify">
                    {cvData.personalInfo.summary}
                  </p>
                </div>

                {/* Experience Timeline */}
                <div className="space-y-6">
                  <h2 className="text-[10px] font-black uppercase tracking-[0.2em] text-text-main border-b-2 border-primary pb-1 inline-block">
                    Kinh nghiệm
                  </h2>
                  <div className="space-y-8">
                    {cvData.experience.map((exp) => (
                      <div key={exp.id} className="relative pl-6 border-l border-border">
                        <div className="absolute -left-[5px] top-1 w-[9px] h-[9px] rounded-full bg-primary" />
                        <div className="flex justify-between items-start mb-1">
                          <h3 className="text-xs font-bold text-text-main">{exp.position}</h3>
                          <span className="text-[9px] font-bold text-text-sub uppercase">{exp.startDate} - {exp.endDate}</span>
                        </div>
                        <p className="text-[10px] font-bold text-primary mb-2 uppercase tracking-wide">{exp.company}</p>
                        <ul className="space-y-1">
                          {exp.description.map((item, i) => (
                            <li key={i} className="text-[9px] text-text-sub flex items-start gap-2">
                              <span className="text-primary mt-1">•</span>
                              {item}
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
