import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Coffee, 
  Brain, 
  Settings,
  Volume2,
  VolumeX,
  Bell,
  CheckCircle2
} from 'lucide-react';
import { cn } from '../lib/utils';
import confetti from 'canvas-confetti';

type Mode = 'focus' | 'shortBreak' | 'longBreak';

const SETTINGS = {
  focus: 25 * 60,
  shortBreak: 5 * 60,
  longBreak: 15 * 60,
};

export default function Pomodoro() {
  const [mode, setMode] = useState<Mode>('focus');
  const [timeLeft, setTimeLeft] = useState(SETTINGS.focus);
  const [isActive, setIsActive] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [sessionsCompleted, setSessionsCompleted] = useState(0);
  
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isActive && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      handleComplete();
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive, timeLeft]);

  const handleComplete = () => {
    setIsActive(false);
    if (!isMuted) {
      const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
      audio.play();
    }
    
    if (mode === 'focus') {
      setSessionsCompleted(prev => prev + 1);
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#4f46e5', '#818cf8', '#c7d2fe']
      });
      setMode('shortBreak');
      setTimeLeft(SETTINGS.shortBreak);
    } else {
      setMode('focus');
      setTimeLeft(SETTINGS.focus);
    }
  };

  const toggleTimer = () => setIsActive(!isActive);

  const resetTimer = () => {
    setIsActive(false);
    setTimeLeft(SETTINGS[mode]);
  };

  const changeMode = (newMode: Mode) => {
    setMode(newMode);
    setIsActive(false);
    setTimeLeft(SETTINGS[newMode]);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = ((SETTINGS[mode] - timeLeft) / SETTINGS[mode]) * 100;

  return (
    <div className="p-8 max-w-2xl mx-auto space-y-12">
      {/* Header */}
      <div className="text-center space-y-4">
        <h2 className="text-3xl font-bold text-text-main">Kỹ thuật Pomodoro</h2>
        <p className="text-text-sub text-sm">Tập trung cao độ để đạt hiệu quả học tập tốt nhất</p>
      </div>

      {/* Timer Card */}
      <div className={cn(
        "p-12 rounded-[2.5rem] border-2 shadow-sm transition-all duration-500 relative overflow-hidden",
        mode === 'focus' ? "bg-primary border-blue-400" : "bg-accent border-emerald-400"
      )}>
        {/* Background Decorative Elements */}
        <div className="absolute top-0 right-0 p-12 opacity-5">
          {mode === 'focus' ? <Brain size={200} className="text-white" /> : <Coffee size={200} className="text-white" />}
        </div>

        <div className="relative z-10 flex flex-col items-center space-y-10">
          {/* Mode Selector */}
          <div className="flex bg-white/10 backdrop-blur-md p-1 rounded-xl border border-white/20">
            {[
              { id: 'focus', label: 'Tập trung', icon: Brain },
              { id: 'shortBreak', label: 'Nghỉ ngắn', icon: Coffee },
              { id: 'longBreak', label: 'Nghỉ dài', icon: Coffee },
            ].map((m) => (
              <button
                key={m.id}
                onClick={() => changeMode(m.id as Mode)}
                className={cn(
                  "px-5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2",
                  mode === m.id ? "bg-white text-text-main shadow-sm" : "text-white/70 hover:text-white"
                )}
              >
                <m.icon size={14} /> {m.label}
              </button>
            ))}
          </div>

          {/* Time Display */}
          <div className="relative">
            <svg className="w-56 h-56 -rotate-90">
              <circle
                cx="112"
                cy="112"
                r="104"
                fill="none"
                stroke="rgba(255,255,255,0.1)"
                strokeWidth="6"
              />
              <motion.circle
                cx="112"
                cy="112"
                r="104"
                fill="none"
                stroke="white"
                strokeWidth="6"
                strokeDasharray={2 * Math.PI * 104}
                animate={{ strokeDashoffset: (2 * Math.PI * 104) * (1 - progress / 100) }}
                transition={{ duration: 1, ease: "linear" }}
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
              <span className="text-6xl font-black tracking-tighter">{formatTime(timeLeft)}</span>
              <span className="text-[10px] font-bold uppercase tracking-widest opacity-60 mt-2">
                {mode === 'focus' ? 'Focus Time' : 'Break Time'}
              </span>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-6">
            <button
              onClick={() => setIsMuted(!isMuted)}
              className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-white hover:bg-white/20 transition-all"
            >
              {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
            </button>
            <button
              onClick={toggleTimer}
              className="w-20 h-20 rounded-full bg-white text-text-main flex items-center justify-center shadow-lg hover:scale-105 transition-all active:scale-95"
            >
              {isActive ? <Pause size={32} fill="currentColor" /> : <Play size={32} fill="currentColor" className="ml-1" />}
            </button>
            <button
              onClick={resetTimer}
              className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-white hover:bg-white/20 transition-all"
            >
              <RotateCcw size={20} />
            </button>
          </div>
        </div>
      </div>

      {/* Stats & Tips */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="sleek-card p-6 flex items-center gap-6">
          <div className="w-14 h-14 rounded-xl bg-primary-light text-primary flex items-center justify-center shrink-0">
            <CheckCircle2 size={28} />
          </div>
          <div>
            <p className="text-[10px] font-bold text-text-sub uppercase tracking-widest">Phiên hoàn thành</p>
            <p className="text-3xl font-black text-text-main">{sessionsCompleted}</p>
          </div>
        </div>
        <div className="sleek-card p-6 flex items-center gap-6">
          <div className="w-14 h-14 rounded-xl bg-amber-50 text-amber-500 flex items-center justify-center shrink-0">
            <Bell size={28} />
          </div>
          <div className="flex-1">
            <p className="text-[10px] font-bold text-text-sub uppercase tracking-widest">Mẹo tập trung</p>
            <p className="text-xs text-text-sub mt-1 italic">"Hãy tắt thông báo điện thoại để đạt trạng thái Flow tốt nhất."</p>
          </div>
        </div>
      </div>
    </div>
  );
}
