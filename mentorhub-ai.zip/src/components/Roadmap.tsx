import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Map, 
  Sparkles, 
  CheckCircle2, 
  Circle, 
  ChevronDown, 
  ChevronUp,
  Target,
  BookOpen,
  Briefcase,
  Lightbulb
} from 'lucide-react';
import { RoadmapYear, RoadmapTask } from '../types';
import { generateRoadmap } from '../services/gemini';
import { cn } from '../lib/utils';

export default function Roadmap() {
  const [goals, setGoals] = useState('');
  const [currentYear, setCurrentYear] = useState(1);
  const [roadmap, setRoadmap] = useState<RoadmapYear[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [expandedYear, setExpandedYear] = useState<number | null>(1);

  const handleGenerate = async () => {
    if (!goals.trim()) return;
    setIsLoading(true);
    try {
      const data = await generateRoadmap(goals, currentYear);
      setRoadmap(data.roadmap);
      setExpandedYear(1);
    } catch (error) {
      console.error('Error generating roadmap:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleTask = (yearIdx: number, taskId: string) => {
    setRoadmap(prev => prev.map((year, idx) => {
      if (idx === yearIdx) {
        return {
          ...year,
          tasks: year.tasks.map(task => 
            task.id === taskId ? { ...task, completed: !task.completed } : task
          )
        };
      }
      return year;
    }));
  };

  return (
    <div className="p-8 max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-600 rounded-full font-bold text-sm">
          <Sparkles size={16} />
          AI Powered Career Path
        </div>
        <h2 className="text-4xl font-bold text-slate-900">Lộ trình 4 năm Đại học</h2>
        <p className="text-slate-500 max-w-xl mx-auto">
          Nhập mục tiêu nghề nghiệp của bạn, AI sẽ thiết kế một lộ trình học tập và phát triển kỹ năng tối ưu nhất.
        </p>
      </div>

      {/* Input Section */}
      <div className="sleek-card p-6 space-y-4">
        <div className="flex flex-col gap-2">
          <label className="text-xs font-bold text-text-sub uppercase tracking-wider">Mục tiêu của bạn là gì?</label>
          <textarea
            value={goals}
            onChange={(e) => setGoals(e.target.value)}
            placeholder="Ví dụ: Trở thành chuyên viên phân tích tài chính tại Big4, hoặc làm Marketing trong ngành FMCG..."
            className="w-full p-4 rounded-xl border border-border focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all min-h-[100px] resize-none text-sm bg-slate-50"
          />
        </div>
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <span className="text-xs font-bold text-text-sub uppercase tracking-wider">Bạn đang là sinh viên năm:</span>
            <div className="flex bg-slate-100 p-1 rounded-lg">
              {[1, 2, 3, 4].map(y => (
                <button
                  key={y}
                  onClick={() => setCurrentYear(y)}
                  className={cn(
                    "px-4 py-1.5 rounded-md text-xs font-bold transition-all",
                    currentYear === y ? "bg-white text-primary shadow-sm" : "text-text-sub hover:text-text-main"
                  )}
                >
                  {y}
                </button>
              ))}
            </div>
          </div>
          <button
            onClick={handleGenerate}
            disabled={isLoading || !goals.trim()}
            className="w-full sm:w-auto px-8 py-3 bg-primary text-white rounded-xl font-bold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 shadow-sm"
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Sparkles size={16} />
            )}
            Tạo lộ trình
          </button>
        </div>
      </div>

      {/* Roadmap Display */}
      <div className="space-y-4">
        {roadmap.map((year, yearIdx) => (
          <motion.div
            key={year.year}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: yearIdx * 0.1 }}
            className="sleek-card overflow-hidden"
          >
            <button
              onClick={() => setExpandedYear(expandedYear === year.year ? null : year.year)}
              className="w-full p-6 flex items-center justify-between hover:bg-slate-50 transition-colors"
            >
              <div className="flex items-center gap-4">
                <div className={cn(
                  "w-10 h-10 rounded-xl flex items-center justify-center font-bold text-lg border-l-4",
                  year.year <= currentYear ? "bg-primary-light text-primary border-primary" : "bg-slate-100 text-text-sub border-slate-300"
                )}>
                  {year.year}
                </div>
                <div className="text-left">
                  <h3 className="font-bold text-text-main text-base">{year.title}</h3>
                  <div className="flex gap-2 mt-1">
                    {year.skills.map((skill, i) => (
                      <span key={i} className="text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 bg-slate-100 text-text-sub rounded">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              {expandedYear === year.year ? <ChevronUp className="text-text-sub" size={18} /> : <ChevronDown className="text-text-sub" size={18} />}
            </button>

            <AnimatePresence>
              {expandedYear === year.year && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="border-t border-slate-100"
                >
                  <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Tasks */}
                    <div className="space-y-4">
                      <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                        <Target size={14} /> Nhiệm vụ chi tiết
                      </h4>
                      <div className="space-y-3">
                        {year.tasks.map((task) => (
                          <div
                            key={task.id}
                            onClick={() => toggleTask(yearIdx, task.id)}
                            className={cn(
                              "p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 group",
                              task.completed 
                                ? "bg-emerald-50 border-emerald-100" 
                                : "bg-slate-50 border-slate-100 hover:border-indigo-200"
                            )}
                          >
                            {task.completed ? (
                              <CheckCircle2 className="text-emerald-500 shrink-0 mt-0.5" size={20} />
                            ) : (
                              <Circle className="text-slate-300 shrink-0 mt-0.5 group-hover:text-indigo-400" size={20} />
                            )}
                            <div>
                              <p className={cn("font-semibold text-sm", task.completed ? "text-emerald-700 line-through" : "text-slate-900")}>
                                {task.title}
                              </p>
                              <p className="text-xs text-slate-500 mt-1">{task.description}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* AI Strategy */}
                    <div className="space-y-4">
                      <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                        <Lightbulb size={14} /> Chiến lược AI
                      </h4>
                      <div className="bg-indigo-50/50 p-6 rounded-2xl border border-indigo-100 relative overflow-hidden">
                        <Sparkles className="absolute -top-2 -right-2 text-indigo-200" size={60} />
                        <p className="text-sm text-indigo-900 leading-relaxed relative z-10 italic">
                          "{year.aiStrategy}"
                        </p>
                        <div className="mt-4 flex items-center gap-2">
                          <div className="w-6 h-6 rounded-full bg-indigo-600 flex items-center justify-center">
                            <Sparkles size={12} className="text-white" />
                          </div>
                          <span className="text-xs font-bold text-indigo-600">AI Mentor Advice</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        ))}
      </div>

      {roadmap.length === 0 && !isLoading && (
        <div className="text-center py-20 opacity-40">
          <Map size={80} className="mx-auto mb-4 text-slate-300" />
          <p className="text-slate-500 font-medium italic">Chưa có lộ trình nào được tạo. Hãy nhập mục tiêu của bạn ở trên!</p>
        </div>
      )}
    </div>
  );
}
