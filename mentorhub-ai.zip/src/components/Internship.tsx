import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Briefcase, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  ArrowRight, 
  Trophy,
  Star,
  Zap,
  MessageSquare,
  ChevronRight
} from 'lucide-react';
import { cn } from '../lib/utils';
import { evaluateInternshipAction } from '../services/gemini';

const scenarios = [
  {
    id: '1',
    title: 'Xử lý hóa đơn sai lệch',
    category: 'Kế toán / Tài chính',
    difficulty: 'Dễ',
    description: 'Bạn phát hiện một hóa đơn từ nhà cung cấp có số tiền chênh lệch 5% so với đơn đặt hàng (PO).',
    context: 'Nhà cung cấp này là đối tác lâu năm của công ty. Kế toán trưởng đang đi vắng.',
    options: [
      { id: 'a', text: 'Tự ý sửa lại hóa đơn cho khớp với PO rồi thanh toán.', score: 20, feedback: 'Sai lầm nghiêm trọng. Bạn không có quyền sửa chứng từ gốc của đối tác.', proTip: 'Chứng từ kế toán là văn bản pháp lý, tuyệt đối không tự ý chỉnh sửa.' },
      { id: 'b', text: 'Liên hệ với nhà cung cấp để yêu cầu giải trình và gửi lại hóa đơn mới.', score: 95, feedback: 'Rất tốt! Đây là quy trình chuẩn để đảm bảo tính minh bạch.', proTip: 'Luôn giữ bằng chứng trao đổi qua email để đối chiếu sau này.' },
      { id: 'c', text: 'Bỏ qua sai lệch nhỏ này và tiến hành thanh toán để giữ quan hệ.', score: 40, feedback: 'Không ổn. Sai lệch nhỏ tích tụ sẽ gây khó khăn khi quyết toán thuế.', proTip: 'Trong tài chính, sự chính xác là ưu tiên hàng đầu, không phải sự nể nang.' },
    ]
  },
  {
    id: '2',
    title: 'Khách hàng phàn nàn về giá',
    category: 'Kinh doanh / Sales',
    difficulty: 'Trung bình',
    description: 'Một khách hàng tiềm năng nói rằng giá của bạn cao hơn 20% so với đối thủ cạnh tranh.',
    context: 'Sản phẩm của bạn có chất lượng tốt hơn và dịch vụ hậu mãi 24/7.',
    options: [
      { id: 'a', text: 'Đồng ý giảm giá ngay lập tức để chốt đơn hàng.', score: 30, feedback: 'Giảm giá quá nhanh làm mất giá trị sản phẩm và lợi nhuận.', proTip: 'Giảm giá là vũ khí cuối cùng, hãy dùng nó một cách chiến lược.' },
      { id: 'b', text: 'Giải thích về giá trị vượt trội (chất lượng, dịch vụ) mà khách hàng nhận được.', score: 90, feedback: 'Chính xác! Hãy tập trung vào "Value" thay vì "Price".', proTip: 'Sử dụng công thức: Giá trị = Lợi ích - Chi phí.' },
      { id: 'c', text: 'Nói rằng đối thủ cạnh tranh có chất lượng kém nên giá mới rẻ.', score: 10, feedback: 'Rất thiếu chuyên nghiệp. Tuyệt đối không nói xấu đối thủ.', proTip: 'Tôn trọng đối thủ là tôn trọng chính mình và khách hàng.' },
    ]
  }
];

export default function Internship() {
  const [currentScenarioIdx, setCurrentScenarioIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [isEvaluating, setIsEvaluating] = useState(false);

  const scenario = scenarios[currentScenarioIdx];
  const result = scenario.options.find(o => o.id === selectedOption);

  const handleSelect = (id: string) => {
    if (showResult) return;
    setSelectedOption(id);
  };

  const handleSubmit = () => {
    if (!selectedOption) return;
    setShowResult(true);
  };

  const nextScenario = () => {
    setSelectedOption(null);
    setShowResult(false);
    setCurrentScenarioIdx((prev) => (prev + 1) % scenarios.length);
  };

  return (
    <div className="p-8 max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-text-main">Thực tập ảo</h2>
          <p className="text-text-sub mt-1 text-sm">Trải nghiệm các tình huống doanh nghiệp thực tế</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right">
            <p className="text-[10px] font-bold text-text-sub uppercase tracking-widest">Tiến độ</p>
            <p className="text-sm font-bold text-text-main">{currentScenarioIdx + 1} / {scenarios.length}</p>
          </div>
          <div className="w-10 h-10 rounded-full border-2 border-primary-light flex items-center justify-center">
            <span className="text-[10px] font-bold text-primary">{Math.round(((currentScenarioIdx + 1) / scenarios.length) * 100)}%</span>
          </div>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {!showResult ? (
          <motion.div
            key="scenario"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            {/* Scenario Card */}
            <div className="sleek-card p-8 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-6">
                <span className={cn(
                  "px-3 py-1 rounded-md text-[9px] font-bold uppercase tracking-widest",
                  scenario.difficulty === 'Dễ' ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"
                )}>
                  {scenario.difficulty}
                </span>
              </div>
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-primary">
                  <Briefcase size={18} />
                  <span className="text-xs font-bold uppercase tracking-wider">{scenario.category}</span>
                </div>
                <h3 className="text-2xl font-bold text-text-main">{scenario.title}</h3>
                <p className="text-text-sub leading-relaxed text-base">
                  {scenario.description}
                </p>
                <div className="bg-slate-50 p-4 rounded-xl border border-border flex items-start gap-3">
                  <AlertCircle className="text-text-sub shrink-0 mt-0.5" size={16} />
                  <p className="text-xs text-text-sub italic">
                    <span className="font-bold text-text-main not-italic">Bối cảnh:</span> {scenario.context}
                  </p>
                </div>
              </div>
            </div>

            {/* Options */}
            <div className="space-y-4">
              <h4 className="text-[10px] font-bold text-text-sub uppercase tracking-widest ml-2">Lựa chọn của bạn</h4>
              <div className="grid grid-cols-1 gap-3">
                {scenario.options.map((option) => (
                  <button
                    key={option.id}
                    onClick={() => handleSelect(option.id)}
                    className={cn(
                      "p-5 rounded-xl border-2 text-left transition-all flex items-center gap-4 group",
                      selectedOption === option.id 
                        ? "border-primary bg-primary-light shadow-sm" 
                        : "border-border bg-white hover:border-slate-300"
                    )}
                  >
                    <div className={cn(
                      "w-7 h-7 rounded-full border-2 flex items-center justify-center text-xs font-bold shrink-0 transition-colors",
                      selectedOption === option.id ? "bg-primary border-primary text-white" : "border-border text-text-sub group-hover:border-slate-400"
                    )}>
                      {option.id.toUpperCase()}
                    </div>
                    <span className={cn(
                      "text-sm font-medium",
                      selectedOption === option.id ? "text-primary" : "text-text-main"
                    )}>
                      {option.text}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleSubmit}
              disabled={!selectedOption}
              className="w-full py-3.5 bg-primary text-white rounded-xl font-bold hover:bg-blue-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2 shadow-sm"
            >
              Xác nhận quyết định <ArrowRight size={18} />
            </button>
          </motion.div>
        ) : (
          <motion.div
            key="result"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-8"
          >
            {/* Score & Feedback */}
            <div className="sleek-card p-10 text-center space-y-6 relative overflow-hidden">
              <div className={cn(
                "absolute top-0 left-0 w-full h-1.5",
                result!.score >= 80 ? "bg-accent" : result!.score >= 50 ? "bg-amber-500" : "bg-rose-500"
              )} />
              
              <div className="inline-flex flex-col items-center">
                <div className={cn(
                  "w-20 h-20 rounded-full flex items-center justify-center text-3xl font-black mb-2",
                  result!.score >= 80 ? "bg-emerald-50 text-accent" : "bg-rose-50 text-rose-600"
                )}>
                  {result?.score}
                </div>
                <span className="text-[10px] font-bold text-text-sub uppercase tracking-widest">Điểm đánh giá</span>
              </div>

              <div className="space-y-2">
                <h3 className="text-2xl font-bold text-text-main">
                  {result!.score >= 80 ? 'Tuyệt vời! 🌟' : 'Cần cải thiện ✍️'}
                </h3>
                <p className="text-text-sub max-w-lg mx-auto leading-relaxed text-sm">
                  {result?.feedback}
                </p>
              </div>

              {/* Pro Tip */}
              <div className="bg-slate-900 p-6 rounded-xl text-white text-left relative group">
                <Zap className="absolute top-4 right-4 text-white/20 group-hover:scale-110 transition-transform" size={24} />
                <h4 className="text-amber-400 font-bold text-[10px] uppercase tracking-wider mb-2 flex items-center gap-2">
                  <Star size={12} fill="currentColor" /> Pro Tip từ Chuyên gia
                </h4>
                <p className="text-white/90 text-sm italic leading-relaxed">
                  "{result?.proTip}"
                </p>
              </div>

              <button
                onClick={nextScenario}
                className="w-full py-3.5 bg-text-main text-white rounded-xl font-bold hover:bg-slate-800 transition-all flex items-center justify-center gap-2 text-sm"
              >
                Tiếp tục tình huống mới <ChevronRight size={18} />
              </button>
            </div>

            {/* Achievement Preview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white p-4 rounded-2xl border border-slate-200 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-500 flex items-center justify-center">
                  <Zap size={20} />
                </div>
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase">Kinh nghiệm</p>
                  <p className="text-sm font-bold text-slate-900">+{result!.score} XP</p>
                </div>
              </div>
              <div className="bg-white p-4 rounded-2xl border border-slate-200 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-500 flex items-center justify-center">
                  <Trophy size={20} />
                </div>
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase">Kỹ năng</p>
                  <p className="text-sm font-bold text-slate-900">Xử lý vấn đề</p>
                </div>
              </div>
              <div className="bg-white p-4 rounded-2xl border border-slate-200 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-500 flex items-center justify-center">
                  <Star size={20} />
                </div>
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase">Đánh giá</p>
                  <p className="text-sm font-bold text-slate-900">Chuyên nghiệp</p>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
