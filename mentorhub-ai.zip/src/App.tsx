import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Roadmap from './components/Roadmap';
import CVBuilder from './components/CVBuilder';
import Internship from './components/Internship';
import MentorChat from './components/MentorChat';
import Achievements from './components/Achievements';
import Pomodoro from './components/Pomodoro';
import { UserProgress } from './types';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [progress, setProgress] = useState<UserProgress>(() => {
    const saved = localStorage.getItem('mentorhub_progress');
    return saved ? JSON.parse(saved) : {
      xp: 1250, // Initial XP for demo
      level: 2,
      streak: 3,
      lastActive: new Date().toISOString(),
      achievements: [
        { id: '1', title: 'Người mới bắt đầu', description: 'Hoàn thành hồ sơ cá nhân lần đầu tiên.', icon: 'User' }
      ]
    };
  });

  useEffect(() => {
    localStorage.setItem('mentorhub_progress', JSON.stringify(progress));
  }, [progress]);

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard progress={progress} />;
      case 'roadmap': return <Roadmap />;
      case 'cv': return <CVBuilder />;
      case 'internship': return <Internship />;
      case 'chat': return <MentorChat />;
      case 'achievements': return <Achievements progress={progress} />;
      case 'pomodoro': return <Pomodoro />;
      default: return <Dashboard progress={progress} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-bg font-sans text-text-main">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="flex-1 overflow-y-auto h-screen relative bg-gradient-to-br from-bg to-slate-100">
        <div className="geometric-bg" />
        
        <header className="h-[72px] glass-header border-b border-border flex items-center justify-between px-8 sticky top-0 z-40">
          <h1 className="text-lg font-bold text-text-main">
            Chào buổi sáng, <strong>Minh Hoàng</strong> 👋
          </h1>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-white text-text-main rounded-full border border-border text-xs font-semibold shadow-sm">
              <span>🔥 15 Ngày liên tiếp</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 bg-white text-amber-500 rounded-full border border-border text-xs font-semibold shadow-sm">
              <span>✨ Cấp độ 12 (Vàng)</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 bg-white text-text-main rounded-full border border-border text-xs font-semibold shadow-sm">
              <span>💰 2,450 XP</span>
            </div>
          </div>
        </header>

        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="max-w-7xl mx-auto relative z-10"
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}
