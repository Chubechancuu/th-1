import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function generateRoadmap(goals: string, currentYear: number) {
  const prompt = `Bạn là một chuyên gia tư vấn nghề nghiệp ngành Kinh tế. 
  Hãy tạo một lộ trình học tập 4 năm chi tiết cho sinh viên Kinh tế năm ${currentYear}.
  Mục tiêu của sinh viên: ${goals}.
  
  Yêu cầu trả về định dạng JSON:
  {
    "roadmap": [
      {
        "year": 1,
        "title": "Năm 1: Xây dựng nền tảng",
        "skills": ["Kỹ năng mềm", "Kinh tế vi mô"],
        "tasks": [
          {"id": "1", "title": "Hoàn thành khóa học X", "description": "Mô tả chi tiết", "category": "academic"}
        ],
        "aiStrategy": "Lời khuyên chiến lược từ AI..."
      },
      ... (đủ 4 năm)
    ]
  }`;

  const response = await ai.models.generateContent({
    model: "gemini-2.0-flash-exp",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
    }
  });

  return JSON.parse(response.text);
}

export async function chatWithMentor(message: string, history: {role: 'user' | 'model', content: string}[]) {
  const contents = history.map(h => ({
    role: h.role,
    parts: [{ text: h.content }]
  }));
  
  contents.push({
    role: 'user',
    parts: [{ text: message }]
  });

  const response = await ai.models.generateContent({
    model: "gemini-2.0-flash-exp",
    contents: contents,
    config: {
      systemInstruction: "Bạn là một Mentor giàu kinh nghiệm trong ngành Kinh tế, luôn sẵn sàng hỗ trợ, động viên và đưa ra lời khuyên thực tế cho sinh viên.",
    }
  });

  return response.text;
}

export async function evaluateInternshipAction(scenario: string, action: string) {
  const prompt = `Tình huống thực tập: ${scenario}
  Hành động của sinh viên: ${action}
  
  Hãy đánh giá hành động này trên thang điểm 100 và đưa ra phản hồi chuyên sâu kèm Pro Tip.
  Trả về JSON:
  {
    "score": number,
    "feedback": "string",
    "proTip": "string"
  }`;

  const response = await ai.models.generateContent({
    model: "gemini-2.0-flash-exp",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
    }
  });

  return JSON.parse(response.text);
}
