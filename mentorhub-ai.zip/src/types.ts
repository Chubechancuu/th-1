export interface UserProgress {
  xp: number;
  level: number;
  streak: number;
  lastActive: string;
  achievements: Achievement[];
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlockedAt?: string;
}

export interface CVData {
  personalInfo: {
    fullName: string;
    email: string;
    phone: string;
    address: string;
    summary: string;
    role: string;
  };
  experience: Experience[];
  education: Education[];
  skills: Skill[];
  languages: string[];
}

export interface Experience {
  id: string;
  company: string;
  position: string;
  startDate: string;
  endDate: string;
  description: string[];
}

export interface Education {
  id: string;
  school: string;
  degree: string;
  startDate: string;
  endDate: string;
}

export interface Skill {
  name: string;
  level: number; // 0-100
}

export interface RoadmapYear {
  year: number;
  title: string;
  skills: string[];
  tasks: RoadmapTask[];
  aiStrategy: string;
}

export interface RoadmapTask {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  category: 'academic' | 'skill' | 'career';
}

export interface InternshipScenario {
  id: string;
  title: string;
  description: string;
  context: string;
  options: InternshipOption[];
}

export interface InternshipOption {
  id: string;
  text: string;
  feedback: string;
  score: number;
  proTip: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
  timestamp: string;
}
